#!/usr/bin/env python
# ampclient.py -- A Twisted AMP client.
# From: Twisted-8.0.1/doc/core/examples/ampclient.py

from twisted.internet import reactor, defer
from twisted.internet.protocol import ClientCreator
from twisted.protocols import amp
from ampserver import Sum, Divide

def doMath():
    # Add two numbers
    d1 = ClientCreator(reactor, amp.AMP).connectTCP('127.0.0.1', 1234)
    d1.addCallback(lambda p: p.callRemote(Sum, a=13, b=81))
    d1.addCallback(lambda result: result['total'])

    # Divide two numbers, raising an exception
    def trapZero(result):
        result.trap(ZeroDivisionError)
        print "Divided by zero: returning INF"
        return 1e1000

    d2 = ClientCreator(reactor, amp.AMP).connectTCP('127.0.0.1', 1234)
    d2.addCallback(lambda p: p.callRemote(Divide, numerator=1234,
                                          denominator=0))
    d2.addErrback(trapZero)

    # Wait until both addition and division have completed
    def done(result):
        print 'Done with math:', result
        reactor.stop()
    defer.DeferredList([d1, d2]).addCallback(done)

if __name__ == '__main__':
    doMath()
    reactor.run()
