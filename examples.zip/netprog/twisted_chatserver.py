#!/usr/bin/env python
# twisted_chatserver.py -- A Twisted chat server.

from twisted.internet.protocol import Factory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor

class Chat(LineReceiver):
    def connectionMade(self):
        self.delimiter = '\n'
        self.userName = None
        self.sendLine(self.factory.prompt)
    
    def lineReceived(self, line):
        if self.userName is not None:
            # Received a line from a logged in user
            self.broadcastLine("<%s>: %s" % (self.userName, line))
        else:
            # User logging in with username line
            if line in self.factory.users:
                self.sendLine("Sorry, but %s is already logged in." % (line,))
                self.transport.loseConnection()
            else:
                self.userName = line
                self.factory.users[self.userName] = self
                self.broadcastLine(self.userName + " logged in.")
    
    def connectionLost(self, reason):
        if self.userName is not None and self.userName in self.factory.users:
            del self.factory.users[self.userName]
            self.broadcastLine(self.userName + " logged out.")
    
    def broadcastLine(self, line):
        for chatobject in self.factory.users.itervalues():
            chatobject.sendLine(line)

factory = Factory()
factory.protocol = Chat
factory.prompt   = "Nickname:"
factory.users    = {}  # Dictionary of (Nickname, Chat object) items.

reactor.listenTCP(7070, factory)
reactor.run()
