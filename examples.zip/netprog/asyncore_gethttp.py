#!/usr/bin/env python
# asyncore_gethttp.py -- A simple web downloader using asyncore.

import socket
import asyncore

HTTP_COMMAND = "GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n"
BUFSIZE = 4096

class HTTPDownloader(asyncore.dispatcher):
    "A class that downloads a web page from an HTTP server"
    
    def __init__(self, host, path, port=80):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))
        self.buffer = HTTP_COMMAND % (path, host)

    def handle_connect(self):
        pass

    def handle_close(self):
        print ''           # add a terminating newline
        self.close()
    
    def handle_read(self):
        print self.recv(BUFSIZE),

    def writable(self):
        return len(self.buffer) > 0

    def handle_write(self):
        sent = self.send(self.buffer)
        self.buffer = self.buffer[sent:]

def getpage(host, path, port=80):
    "Download a page path from host:port using HTTP protocol"
    
    getter = HTTPDownloader(host, path, port)
    asyncore.loop()

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "host path [port]"
        sys.exit(1)
    host, path, port = sys.argv[1], sys.argv[2], 80
    if len(sys.argv) == 4: port = int(sys.argv[3])
    
    getpage(host, path, port)
