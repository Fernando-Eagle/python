#!/usr/bin/env python
# imaplib_imap4client.py -- Fetch mail headers from an IMAP mailbox

from pprint import pprint
from getpass import getpass

SERVER = raw_input("IMAP4 Server: ")
MBOX   = raw_input("IMAP4 Mailbox: ")
USER   = raw_input("IMAP4 User: ")
PASSWD = getpass("IMAP4 Password: ")
DEBUG  = True

from imaplib import IMAP4_SSL as IMAP4

imap4 = IMAP4(SERVER)
imap4.login(USER, PASSWD)

pprint(imap4.list()); print

imap4.select(MBOX, readonly=True)
pprint(imap4.fetch('1:*',
                   '(UID BODY[HEADER.FIELDS (SUBJECT)] BODY[TEXT])'))

imap4.logout()
