#!/usr/bin/env python
# iface.py -- describe zope.interface Interfaces

import zope.interface

def iface(intface):
    "Describe a zope.interface Interface"
    print intface.getDoc()
    for name, descr in intface.namesAndDescriptions():
        print name, descr.getSignatureString(),
        print descr.getDoc()
