#!/usr/bin/env python
# twisted_helloclient.py -- A Hello, Twisted World client

from twisted.internet.protocol import ClientFactory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor
from sys import stdout

class HelloWorld(LineReceiver):
    def connectionMade(self):
        self.delimiter = '\n'
        self.state = 0        # 0: waiting for prompt, 1: waiting for greeting
    
    def lineReceived(self, line):
        self.line = line
        
        if self.state == 0:
            # Got prompt from server: reply by sending name
            try:
                self.name = raw_input(self.line + " ")
                self.sendLine(self.name)
            except EOFError:
                self.sendLine("User didn't answer")
            finally:
                self.state = 1
        
        elif self.state == 1:
            # Got greeting from server: print out, and close conn
            stdout.write(self.line + "\r\n")
            self.transport.loseConnection()
            self.state = 2
        
        else:
            # Should not happen. Got spurious line
            stdout.write("Got spurious line: " + self.line + "\r\n")
            self.transport.loseConnection()

class HelloWorldFactory(ClientFactory):
    
    protocol = HelloWorld
    
    def clientConnectionLost(self, connector, reason):
        print "clientConnectionLost():", reason.value
        reactor.stop()
    def clientConnectionFailed(self, connector, reason):
        print "clientConnectionFailed():", reason.value
        reactor.stop()

reactor.connectTCP('localhost', 7070, HelloWorldFactory())
reactor.run()
