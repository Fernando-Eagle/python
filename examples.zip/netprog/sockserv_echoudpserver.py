#!/usr/bin/env python
# sockserv_echoudpserver.py -- A simple UDP echo server with SocketServer

from SocketServer import UDPServer, DatagramRequestHandler

class EchoHandler(DatagramRequestHandler):
    def handle(self):
        print "Serving client:", self.client_address
        for line in (self.rfile):
            self.wfile.write("S:" + line)

UDPServer.allow_reuse_address = True
srv = UDPServer(('', 7070), EchoHandler)
srv.serve_forever()
