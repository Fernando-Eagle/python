#!/usr/bin/env python
# twisted_maybedeferred.py -- wrap a synchroneous function into an async one.

from twisted.internet import reactor
from twisted.internet.defer import Deferred, maybeDeferred

def syncDeepThought(bias=0):
    return 42+bias

def asyncDeepThought(bias=0):
    d = Deferred()
    reactor.callLater(2, d.callback, 42+bias)
    return d

def receiveSyncResult(bias=0):
    printResult(syncDeepThought(bias))

def receiveAsyncResult(bias=0):
    d = asyncDeepThought(bias)
    d.addCallback(printResult)

def receiveSyncAsyncResultFromFunction(resultReceiverFunction, bias=0):
    d = maybeDeferred(resultReceiverFunction, bias)
    d.addCallback(printResult)

def printResult(data):
    print "The result is", data

if __name__ == '__main__':
    receiveSyncResult(bias=100)
    receiveAsyncResult(bias=200)
    receiveSyncAsyncResultFromFunction(syncDeepThought, bias=300)
    receiveSyncAsyncResultFromFunction(asyncDeepThought, bias=400)
    
    reactor.callLater(10, lambda: reactor.stop())
    reactor.run()
