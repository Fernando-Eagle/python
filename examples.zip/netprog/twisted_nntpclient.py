#!/usr/bin/env python
# twisted_nntpclient.py -- A simple Twisted NNTP client

from twisted.internet import reactor
from twisted.internet.protocol import ClientFactory
from twisted.news.nntp import NNTPClient
from email import message_from_string
from pprint import pprint

class MyNNTPClient(NNTPClient):
    def connectionMade(self):
        NNTPClient.connectionMade(self)
        if self.factory.newsgroup is None:
            self.fetchGroups()
        else:
            self.fetchGroup(self.factory.newsgroup)
    
    def gotAllGroups(self, groups):
        pprint(groups)
        self.quit()
        reactor.stop()
    
    def gotGroup(self, info):
        if self.factory.articlenr is None:
            narts, nbegin, nend, gname = info
            for artnr in range(int(nbegin), int(nend)+1):
                self.fetchHead(artnr)
            print info
            # No matter how long it takes, quit after 60 seconds
            reactor.callLater(60, self.quit)
        else:
            self.fetchArticle(self.factory.articlenr)

    def gotHead(self, head):
        msg = message_from_string(head)
        artnr = msg['Xref'].split(' ')[1].split(':')[1]
        print "%10s %-60s" % (artnr, msg['Subject'])

    def gotArticle(self, article):
        print '-' * 70
        msg = message_from_string(article)
        print msg['Subject'][:70]
        print msg.get_payload()
        self.quit()
        reactor.stop()

    def gotAllGroupsFailed(self, error):
        print 'gotAllGroupsFailed', error
    def gotArticleFailed(self, error):
        print 'gotArticleFailed', error
    def gotGroupFailed(self, error):
        print 'gotGroupFailed', error
    def gotHeadFailed(self,error):
        print 'gotHeadFailed', error

class MyNNTPClientFactory(ClientFactory):
    protocol = MyNNTPClient
    def __init__(self, newsgroup, articlenr):
        self.newsgroup = newsgroup
        self.articlenr = articlenr

if __name__ == '__main__':
    import sys
    newsserver, newsgroup, articlenr = None, None, None
    if len(sys.argv) >= 4: articlenr = sys.argv[3]
    if len(sys.argv) >= 3: newsgroup = sys.argv[2]
    if len(sys.argv) >= 2: newsserver = sys.argv[1]

    nfactory = MyNNTPClientFactory(newsgroup, articlenr)
    reactor.connectTCP(newsserver, 119, nfactory)
    reactor.run()
