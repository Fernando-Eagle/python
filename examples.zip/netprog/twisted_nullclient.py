#!/usr/bin/env python
# twisted_nullclient.py -- A client for the lazy nullserver.

from twisted.internet.protocol import Protocol, ClientFactory
from twisted.internet import reactor
from sys import stdout

class NullClient(Protocol):
    def dataReceived(self, data):
        stdout.write(data)

class NullClientFactory(ClientFactory):
    
    protocol = NullClient
    
    def clientConnectionLost(self, connector, reason):
        print "clientConnectionLost():", reason.value
        reactor.stop()
    def clientConnectionFailed(self, connector, reason):
        print "clientConnectionFailed():", reason.value
        reactor.stop()

reactor.connectTCP('localhost', 7070, NullClientFactory())
reactor.run()
