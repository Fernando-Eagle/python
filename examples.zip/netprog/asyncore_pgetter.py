#!/usr/bin/env python
# asyncore_pgetter.py -- A parallel web downloader using asyncore

import socket
import asyncore
import urlparse

HTTP_COMMAND = "GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n"
BUFSIZE = 4096

class HTTPDownloader(asyncore.dispatcher):
    "A class that downloads a web page from an HTTP server into a file"
    
    def __init__(self, url, filename):
        # Register channel with event loop
        asyncore.dispatcher.__init__(self)
        
        # Parse url, but only for the form scheme://netloc/path
        (scheme, netloc, path, query, fragment) = urlparse.urlsplit(url)
        if ':' in netloc:
            host, port_as_str = netloc.split(':')
            if port_as_str == '': port_as_str = '80'
            port = int(port_as_str)
        else:
            host, port = netloc, 80
        
        # Create socket and open connection
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))
        
        # Create destination file
        self.thefile = open(filename, 'wb')
        
        # Prepare send buffer
        self.buffer = HTTP_COMMAND % (path, host)
    
    def handle_connect(self):
        pass

    def handle_close(self):
        self.thefile.close()
        self.close()
    
    def handle_read(self):
        data = self.recv(BUFSIZE)
        if data:
            self.thefile.write(data)
    
    def writable(self):
        return len(self.buffer) > 0
    
    def handle_write(self):
        sent = self.send(self.buffer)
        self.buffer = self.buffer[sent:]

def getpage(url, filename):
    "Download a page from URL using HTTP, and save it in filename"
    
    # Initialize and register channel into global map
    getter = HTTPDownloader(url, filename)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 3 or len(sys.argv) % 2 != 1:
        print >>sys.stderr, "Usage:", sys.argv[0], "url file [url file...]"
        sys.exit(1)

    getters = []
    for i in range(len(sys.argv) / 2):
        url, filename = sys.argv[i*2+1], sys.argv[i*2+2]
        try:
            getters.append(getpage(url, filename))
        except Exception, e:
            print url, filename, e   # skip this one.
    asyncore.loop()
