#!/usr/bin/env python
# twisted_deferedserver.py -- a server sending slowly its replies

from twisted.internet import reactor, defer
from twisted.internet.protocol import Protocol, Factory
from sys import stdout

class DeepThoughtProtocol(Protocol):
    "A protocol object that takes some time to reply"
    
    def __init__(self):
        "Initialize the protocol object"
        
        self.d = defer.Deferred()
        self.d.addCallback(self.sendTheAnswer)
    
    def connectionMade(self):
        "We've got a connection. Prepare a Deferred object for later."
        
        stdout.write("Got connection\r\n")        # DEBUG
        reactor.callLater(self.factory.delay,
                          self.d.callback,
                          self.factory.answer)

    def sendTheAnswer(self, answer):
        "Send the answer to the client and close connection"
        
        self.transport.write("The answer is: %s\r\n" % (answer,))
        self.transport.loseConnection()

def create_server(port):
    "Create a server on on Port"
    
    factory = Factory()
    factory.protocol = DeepThoughtProtocol
    factory.answer = 42
    factory.delay = 5

    reactor.listenTCP(port, factory)
    reactor.run()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "port"
        sys.exit(1)
    port = int(sys.argv[1])

    create_server(port)
