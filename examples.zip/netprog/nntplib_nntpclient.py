#!/usr/bin/env python
# nntplib_nntpclient.py -- A simple NNTP newsreader

from getpass import getpass
from pprint import pprint
from nntplib import NNTP

# 1. Login to a server
srv = NNTP(host=raw_input("NNTP Server: "),
           user=raw_input("NNTP User  : "),
           password=getpass("NNTP Passwd: "))
print srv.getwelcome()

# 2. Get list of all groups (glist is a list of (group, last, first, flag))
resp, glist = srv.list()

# 3. Show all 'comp.lang.python' groups
gpython = [ t for t in glist if 'comp.lang.python' in t[0] ]
gpython.sort()
for t in gpython:
    print t

# 4. Show a few article headers from comp.lang.python.announce
resp, count, first, last, name = srv.group('comp.lang.python.announce')
print "comp.lang.python.announce: %s - %s available" % (first, last)

pprint(srv.xhdr('subject', '%s-%s' % (raw_input("Begin: "),
                                      raw_input("End: "))))

# 5. Show an article
resp, nr, id, lines = srv.body(raw_input('Article Number: '))
print '\n'.join(lines)

# 6. That's all, folks!
srv.quit()
