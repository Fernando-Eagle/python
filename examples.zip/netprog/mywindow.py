#!/usr/bin/env python
# mywindow.py -- a widget that implements the IWidget interface

import zope.interface
from iwidget import IWidget

class MyWindow(object):
    "This is a Widget that implements the IWidget interface"
    
    zope.interface.implements(IWidget)
    
    widgetCount = 0
    
    def __init__(self, width, height):
        MyWindow.widgetCount = MyWindow.widgetCount + 1
        self.width = width
        self.height = height
    
    def draw(self):
        print "I am a MyWindow(%d,%d)" % (self.width, self.height)
    
    def resize(self, width, height):
        self.width = width
        self.height = height
    
    def __repr__(self):
        return "<MyWindow(%d,%d)>" % (self.width, self.height)
