#!/usr/bin/env python
# twisted_defertothread.py -- run a blocking / cpu-bound func in its own thread

from twisted.internet.threads import deferToThread
from twisted.internet import reactor

def long_or_blocking(bias=0):
    return 42+bias

def call_long_or_blocking(func, bias=0):
    d = deferToThread(func, bias)
    d.addCallback(printResult)

def printResult(result):
    print "The result is", result

call_long_or_blocking(long_or_blocking, bias=100)

reactor.callLater(5, lambda: reactor.stop())
reactor.run()
