#!/usr/bin/env python
# sockserv_helloudpserver2.py -- A simple UDP hello server with SocketServer

from SocketServer import UDPServer, DatagramRequestHandler

class HelloHandler(DatagramRequestHandler):
    def handle(self):
        print "Serving client:", self.client_address
        self.wfile.write('Hello Client! I am a HelloHandler\r\n')

UDPServer.allow_reuse_address = True
srv = UDPServer(('', 7070), HelloHandler)
srv.serve_forever()
