#!/usr/bin/env python
# tcpserver.py -- a single threaded TCP server with sockets

import socket

def create_server(port, host=''):
    "Create a listening socket, and accept connections in an endless loop"
    
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    s.listen(5)
    print "Server started on port %s" % (port,)

    try:
        while True:
            c, (raddr, rport) = s.accept()
            print "Accepted connection from %s:%s" % (raddr, rport)
            c.sendall("Hi (%s:%s)!\r\n" % (raddr, rport))
            c.close()
    except KeyboardInterrupt:
        s.close()
        print "Server stopped"

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "port"
        sys.exit(1)
    port = int(sys.argv[1])
    create_server(port)
