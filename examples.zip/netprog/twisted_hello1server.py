#!/usr/bin/env python
# twisted_hello1server.py -- A simple hello, world server in Twisted

from twisted.internet.protocol import Protocol, Factory
from twisted.internet import reactor
from sys import stdout

class SimpleServerHelloWorld(Protocol):
    "A Hello World server-side Protocol"
    
    def connectionMade(self):
        stdout.write("Client connection accepted...\r\n")
        self.transport.write("Hello, Twisted World!\r\n")
        self.transport.loseConnection()

def start_server(port=7111):
    "Start server protocol on this port"
    
    factory = Factory()
    factory.protocol = SimpleServerHelloWorld
    
    reactor.listenTCP(port, factory)
    reactor.run()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "port"
        sys.exit(1)
    port = int(sys.argv[1])
    
    start_server(port)
