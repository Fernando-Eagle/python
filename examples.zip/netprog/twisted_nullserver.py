#!/usr/bin/env python
# twisted_nullserver.py -- a lazy server that closes all connections

from twisted.internet.protocol import Factory, Protocol
from twisted.internet import reactor

class ConnectionCloser(Protocol):
    def connectionMade(self):
        self.transport.loseConnection()

factory = Factory()
factory.protocol = ConnectionCloser

reactor.listenTCP(7070, factory)
reactor.run()
