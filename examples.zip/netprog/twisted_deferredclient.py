#!/usr/bin/env python
# twisted_deferredclient.py -- a client talking to a slow server

from twisted.internet import reactor, defer
from twisted.internet.protocol import ClientFactory
from twisted.protocols.basic import LineReceiver
from sys import stdout

class DeepThoughtClientProtocol(LineReceiver):
    "A protocol object that returns a result in a Deferred"
    
    def lineReceived(self, line):
        "We've finally got the reply"
        self.answer = line
        self.transport.loseConnection()
        self.factory.d.callback(self.answer)

class DeepThoughtDeferredFactory(ClientFactory):
    "A factory that holds a deferred for the DeepThoughtClientProtocol"
    
    protocol = DeepThoughtClientProtocol
    
    def __init__(self):
        self.d = defer.Deferred()

def my_own_callback(result):
    "A custom callback function"
    stdout.write("Got Result: " + result + "\r\n")
    reactor.stop()

def start_client(host, port):
    "Create a client"
    
    cf = DeepThoughtDeferredFactory()
    cf.d.addCallback(my_own_callback)
    
    reactor.connectTCP(host, port, cf)
    reactor.run()

if __name__ == '__main__':
        import sys
        if len(sys.argv) != 3:
            print >>sys.stderr, "Usage:", sys.argv[0], "host port"
            sys.exit(1)
        host, port = sys.argv[1], int(sys.argv[2])
        
        start_client(host, port)
