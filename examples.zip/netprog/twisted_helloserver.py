#!/usr/bin/env python
# twisted_helloserver.py -- A Hello, Twisted World server.

from twisted.internet.protocol import Factory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor

class HelloWorld(LineReceiver):
    def connectionMade(self):
        self.delimiter = '\n'
        self.sendLine(self.factory.prompt)
    
    def lineReceived(self, line):
        self.name = line
        self.sendLine("Hello, " + self.name)
        self.transport.loseConnection()

factory = Factory()
factory.protocol = HelloWorld
factory.prompt = "Hello! What's your name?"

reactor.listenTCP(7070, factory)
reactor.run()
