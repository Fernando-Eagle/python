#!/usr/bin/env python
# twisted_hello2server.py -- A chatty hello, world server in Twisted

from twisted.internet.protocol import Factory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor
from sys import stdout

class ChattyServerHelloWorld(LineReceiver):
    "A Chatty Hello World server-side Protocol"
    
    def connectionMade(self):
        "Client just connected to us: send prompt"
        
        stdout.write("Client connection accepted...\r\n")    # DEBUG
        self.sendLine(self.factory.prompt)
    
    def lineReceived(self, line):
        "Got reply from client: send personalized greeting and close conn"
        
        self.name = line
        stdout.write("Got reply: " + line + "\r\n")          # DEBUG
        self.sendLine("Hello, " + self.name)
        self.transport.loseConnection()

def start_server(port=7111):
    "Start server protocol on this port"
    
    factory = Factory()
    factory.protocol = ChattyServerHelloWorld
    factory.prompt = "Hello! What's your name?"
    
    reactor.listenTCP(port, factory)
    reactor.run()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "port"
        sys.exit(1)
    port = int(sys.argv[1])
    
    start_server(port)
