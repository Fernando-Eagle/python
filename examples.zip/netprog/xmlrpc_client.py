#!/usr/bin/env python
# xmlrpc_client.py -- A simple XML-RPC client of the calculator server.

import xmlrpclib

prx = xmlrpclib.ServerProxy('http://localhost:7070',
                            allow_none=True, verbose=False)

print prx.echo('Hello, XML-RPC World!')
print prx.none()
print prx.himom()
print prx.addlist([5,6,7,8,9,10])

print prx.add(3,2), prx.sub(3,2), prx.mul(3,2), prx.div(7,2), prx.idiv(7,2)

try:
    print prx.idiv(3,0)
except xmlrpclib.Fault, f:
    print f

print "Remote methods:"
print '\n'.join(['    ' + meth for meth in prx.system.listMethods()])

print "That's all, folks!"
