# twisted_nullserver3.tac -- a lazy twistd server that closes all connections

from twisted.application import internet, service
from twisted.internet.protocol import Protocol, Factory
from twisted.internet import reactor

class ConnectionCloser3(Protocol):
    def connectionMade(self):
        self.transport.write("Sorry, I don't accept connections. Bye!\r\n")
        self.transport.loseConnection()

factory = Factory()
factory.protocol = ConnectionCloser3

application = service.Application('nullserver3', uid=65534, gid=65534)
itcp = internet.TCPServer(94, factory)
itcp.setServiceParent(service.IServiceCollection(application))
