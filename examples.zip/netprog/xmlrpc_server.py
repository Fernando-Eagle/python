#!/usr/bin/env python
# xmlrpc_server.py -- A simple calculator server, accessible through XML-RPC

from __future__ import division
from SimpleXMLRPCServer import SimpleXMLRPCServer

class Calculator(object):
    def add(self, x, y): return x + y
    def sub(self, x, y): return x - y
    def mul(self, x, y): return x * y
    def div(self, x, y): return x / y
    def idiv(self, x, y): return x // y

def NoneFunc(): return None
def HiMomFunc(): return ['Hi', 'Mom']
def AddListFunc(lst): return sum(lst)

srv = SimpleXMLRPCServer(('', 7070), allow_none=True)
srv.register_introspection_functions()

srv.register_instance(Calculator())
srv.register_function(NoneFunc, 'none')
srv.register_function(HiMomFunc, 'himom')
srv.register_function(AddListFunc, 'addlist')
srv.register_function(lambda s: s, 'echo')

srv.serve_forever()
