#!/usr/bin/env python
# twisted_pbechoclient.py -- An echo client with perspective and cred
# From: Twisted-8.0.1/doc/core/examples/pbechoclient.py

from twisted.internet import defer, reactor
from twisted.spread import pb
from twisted.cred.credentials import UsernamePassword

from twisted_pbechoserver import DefinedError

def success(message):
    print "Message received:", message

def failure(error):
    t = error.trap(pb.Error, DefinedError)
    print "error received:", t

def connected(perspective):
    # Call fnction "error", get exception as result
    d1 = perspective.callRemote('error')
    d1.addCallbacks(success, failure)
    
    # Call function "echo", get result.
    d2 = perspective.callRemote('echo', "hello world")
    d2.addCallbacks(success, failure)
    
    # Wait for both callbacks to kill reactor
    dmeta = defer.DeferredList([d1, d2])
    dmeta.addCallback(lambda _: reactor.stop())

factory = pb.PBClientFactory()
dlogin = factory.login(UsernamePassword("guest", "guest"))
dlogin.addCallbacks(connected, failure)

reactor.connectTCP("localhost", pb.portno, factory)
reactor.run()
