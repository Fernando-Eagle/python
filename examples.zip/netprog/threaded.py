#!/usr/bin/env python
# threaded.py -- a threaded and delayed decorator

import threading
import decorator

def delayed(nsec):
    "A factory of decorators which launch a function after a delay"
    def delayed_call(f, *p, **kw):
        "Call f(*p, **kw) in a thread after a delay"
	thread = threading.Timer(nsec, f, p, kw)
	thread.start()
	return thread
    return decorator.decorator(delayed_call)

threaded = delayed(0)
