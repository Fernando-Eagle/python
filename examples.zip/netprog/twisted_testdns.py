#!/usr/bin/env python
# twisted_testdns.py -- from Twisted-8.0.1/doc/names/examples/testdns.py

import sys, pprint
from twisted.names import client
from twisted.internet import reactor

def cb_address(a):
    print 'Addresses:'
    pprint.pprint(a)

def cb_mails(a):
    print 'Mail Exchangers:'
    pprint.pprint(a)

def cb_nameservers(a):
    print 'Nameservers:'
    pprint.pprint(a)

def cb_error(f):
    print 'gotError'
    f.printTraceback()
    
    from twisted.internet import reactor
    reactor.stop()

if __name__ == '__main__':
    import sys

    r = client.Resolver('/etc/resolv.conf')

    dA = r.lookupAddress(sys.argv[1])
    dMX = r.lookupMailExchange(sys.argv[1])
    dSOA = r.lookupNameservers(sys.argv[1])
    
    dA.addCallback(cb_address).addErrback(cb_error)
    dMX.addCallback(cb_mails).addErrback(cb_error)
    dSOA.addCallback(cb_nameservers).addErrback(cb_error)
    
    reactor.callLater(4, reactor.stop)
    reactor.run()
