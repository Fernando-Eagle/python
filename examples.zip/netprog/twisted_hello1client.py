#!/usr/bin/env python
# twisted_hello1client.py -- A simple hello, world client in Twisted

from twisted.internet.protocol import Protocol, ClientFactory
from twisted.internet import reactor
from sys import stdout

class SimpleClientHelloWorld(Protocol):
    "A Hello World client-side Protocol"
    
    def dataReceived(self, data):
        stdout.write(data)

class SimpleClientFactoryHelloWorld(ClientFactory):
    "A Factory for SimpleClientHelloWorld protocol"
    
    protocol = SimpleClientHelloWorld

    def clientConnectionLost(self, connector, reason):
        reactor.stop()

    def clientConnectionFailed(self, connector, reason):
        reactor.stop()

def start_client(host='localhost', port=7111):
    "Start client protocol on this port"
    
    reactor.connectTCP(host, port, SimpleClientFactoryHelloWorld())
    reactor.run()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "host port"
        sys.exit(1)
    host, port = sys.argv[1], int(sys.argv[2])
    
    start_client(host, port)
