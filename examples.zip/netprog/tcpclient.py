#!/usr/bin/env python
# tcpclient.py -- a single threaded TCP client with sockets

import socket

BLOCKSIZE = 1024

def create_client(host, port):
    "Create a connection to a server, read and print whole server reply"
    
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    
    while True:
        buf = s.recv(BLOCKSIZE)
        if not buf:
            break
        print buf,
    
    s.close()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "host port"
        sys.exit(1)
    host, port = sys.argv[1], int(sys.argv[2])

    create_client(host, port)
