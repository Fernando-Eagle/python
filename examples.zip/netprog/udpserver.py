#!/usr/bin/env python
# udpserver.py -- a single threaded UDP server with sockets

import socket

BUFSIZE = 1024

def create_server(port, host=''):
    "Create a UDP socket, and echo received datagrams in an endless loop"
    
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    print "Server started on port %s" % (port,)
    
    try:
        while True:
            # Receive a datagram into data_in
            data_in, (raddr, rport) = s.recvfrom(BUFSIZE)
            print "Received datagram from %s:%s" % (raddr, rport)
            
            # Prepare reply
            data = data_in.strip()   # remove trailing newline
            data_out = "Hi (%s:%s)! You've sent: [%s]\n" % (raddr, rport, data)
            
            # Send reply data_out back to sender
            s.sendto(data_out, (raddr, rport)) # simply send data back!
    except KeyboardInterrupt:
        s.close()
        print "Server stopped"

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "port"
        sys.exit(1)
    port = int(sys.argv[1])
    create_server(port)
