#!/usr/bin/env python
# iwidget.py -- a simple interface

import zope.interface

class IWidget(zope.interface.Interface):
    "An IWidget can draw and resize itself"

    widgetCount = zope.interface.Attribute("How many Widgets created so far")

    def draw():
        "Draw the widget"

    def resize(width, height):
        "Resize the widget"
