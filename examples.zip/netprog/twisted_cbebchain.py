#!/usr/bin/env python
# twisted_cbebchain.py -- shows use of twisted callback and errback chains

from twisted.internet import reactor
from twisted.internet.defer import Deferred
from twisted.python.failure import Failure

def cb1(data): print "cb1(%s)" % (data,); return data
def cb2(data): print "cb2(%s)" % (data,); return data
def cb3(data): print "cb3(%s)" % (data,); raise Exception("CB3 Exception!");
def cb4(data): print "cb4(%s)" % (data,); return data

def eb1(failure): print "eb1(%s)" % (failure.getErrorMessage(),); raise failure
def eb2(failure): print "eb2(%s)" % (failure.getErrorMessage(),); raise failure
def eb3(failure):
    print "eb3(%s)" % (failure.getErrorMessage(),)
    return "corrected data"
def eb4(failure): print "eb4(%s)" % (failure.getErrorMessage(),); raise failure

d = Deferred()
d.addCallback(cb1).addCallback(cb2).addCallback(cb3).addCallback(cb4)
d.addErrback(eb1).addErrback(eb2).addErrback(eb3).addErrback(eb4)

d.callback("some data")    # kick off callback chain

reactor.callLater(10, lambda: reactor.stop())   # commit suicide in 10 seconds
reactor.run()
