#!/usr/bin/env python
# twisted_nullserver2.py -- a lazy server that closes all connections

from twisted.internet.protocol import Protocol, Factory
from twisted.internet import reactor

class ConnectionCloser2(Protocol):
    def connectionMade(self):
        self.transport.write("Sorry, I don't accept connections. Bye!\r\n")
        self.transport.loseConnection()

factory = Factory()
factory.protocol = ConnectionCloser2

reactor.listenTCP(7070, factory)
reactor.run()
