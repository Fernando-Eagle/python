#!/usr/bin/env python
# udpclient.py -- a single threaded UDP client with sockets

import socket

BUFSIZE = 1024

def create_client(host, port):
    "Connect to a UDP server, send input, and print whole server reply"
    
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    while True:
        data = read_data_from_user()
        if data == '':
            break
        s.sendto(data, (host, port))
        data_in, (raddr, rport) = s.recvfrom(BUFSIZE)
        print '!', data_in,
    
    s.close()

def read_data_from_user():
    "Read data from user and return as string"
    return raw_input('? ').strip()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "host port"
        sys.exit(1)
    host, port = sys.argv[1], int(sys.argv[2])
    
    create_client(host, port)
