#!/usr/bin/env python
# sockserv_hellotcpserver.py -- A simple TCP hello server with SocketServer

from SocketServer import TCPServer, BaseRequestHandler

class HelloHandler(BaseRequestHandler):
    def handle(self):
        print "Serving client:", self.client_address
        self.request.sendall('Hello Client! I am a HelloHandler\r\n')

TCPServer.allow_reuse_address = True
srv = TCPServer(('', 7070), HelloHandler)
srv.serve_forever()
