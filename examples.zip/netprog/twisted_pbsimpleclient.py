#!/usr/bin/env python
# twisted_pbsimpleclient.py -- A simple echo client with perspective.
# From: Twisted-8.0.1/doc/core/examples/pbsimpleclient.py

from twisted.spread import pb
from twisted.internet import reactor
from twisted.python import util

factory = pb.PBClientFactory()

d = factory.getRootObject()

d.addCallback(lambda object: object.callRemote("echo", "hello network"))
d.addCallback(lambda echo: 'server echoed: ' + echo)
d.addErrback(lambda reason: 'error: ' + str(reason.value))

d.addCallback(util.println)
d.addCallback(lambda _: reactor.stop())

reactor.connectTCP("localhost", 8789, factory)
reactor.run()
