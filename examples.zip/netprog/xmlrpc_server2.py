#!/usr/bin/env python
# xmlrpc_server2.py -- A self-documenting XML-RPC calculator server

from __future__ import division
from DocXMLRPCServer import DocXMLRPCServer

class Calculator(object):
    "A calculator object"
    def add(self, x, y): "Add two numbers";      return x + y
    def sub(self, x, y): "Subtract two numbers"; return x - y
    def mul(self, x, y): "Multiply two numbers"; return x * y
    def div(self, x, y): "Divide two numbers";   return x / y
    def idiv(self, x, y): "Divide two integers"; return x // y

def NoneFunc(): "A function which returns None"; return None
def HiMomFunc(): "A function which returns a list"; return ['Hi', 'Mom']
def AddListFunc(lst): "A function which sums a list"; return sum(lst)

srv = DocXMLRPCServer(('', 7070))
srv.allow_none = True
srv.set_server_title('XML-RPC Calculator')
srv.set_server_name('pythonbook.hajji.name')
srv.set_server_documentation('I am a simple XML-RPC Calculator')

srv.register_introspection_functions()

srv.register_instance(Calculator())
srv.register_function(NoneFunc, 'none')
srv.register_function(HiMomFunc, 'himom')
srv.register_function(AddListFunc, 'addlist')
srv.register_function(lambda s: s, 'echo')

srv.serve_forever()
