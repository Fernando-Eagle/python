#!/usr/bin/env python
# twisted_smallservers.py -- Some inetd small servers written in Twisted
# run as: twistd -ny twisted_smallservers.py

from twisted.internet.protocol import Factory
from twisted.protocols import wire

from twisted.application import internet
from twisted.application import service as srv
from twisted.internet import reactor

f_echo    = Factory(); f_echo.protocol    = wire.Echo
f_discard = Factory(); f_discard.protocol = wire.Discard
f_daytime = Factory(); f_daytime.protocol = wire.Daytime
f_chargen = Factory(); f_chargen.protocol = wire.Chargen
f_time    = Factory(); f_time.protocol    = wire.Time

app = srv.Application('twistedinetd', uid=65534, gid=65534)
application = app  # twistd needs an 'application' variable for -y to work

internet.TCPServer(7, f_echo).setServiceParent(srv.IServiceCollection(app))
internet.TCPServer(9, f_discard).setServiceParent(srv.IServiceCollection(app))
internet.TCPServer(13, f_daytime).setServiceParent(srv.IServiceCollection(app))
internet.TCPServer(19, f_chargen).setServiceParent(srv.IServiceCollection(app))
internet.TCPServer(37, f_time).setServiceParent(srv.IServiceCollection(app))
