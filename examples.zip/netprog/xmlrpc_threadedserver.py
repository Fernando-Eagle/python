#!/usr/bin/env python
# xmlrpc_threadedserver.py -- A threaded XML-RPC server.

from SimpleXMLRPCServer import SimpleXMLRPCServer
from SocketServer import ThreadingMixIn
from time import sleep

def SlowFunc(): sleep(5); return 42
def FastFunc(): return 4711

class ThreadedSimpleXMLRPCServer(ThreadingMixIn, SimpleXMLRPCServer): pass

srv = ThreadedSimpleXMLRPCServer(('', 7070), allow_none=True)
srv.register_introspection_functions()
srv.register_function(SlowFunc)
srv.register_function(FastFunc)

srv.serve_forever()
