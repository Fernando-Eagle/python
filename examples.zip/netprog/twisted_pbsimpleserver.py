#!/usr/bin/env python
# twisted_pbsimpleserver.py -- A simple echo server with perspective.
# From: Twisted-8.0.1/doc/core/examples/pbsimple.py

from twisted.spread import pb
from twisted.internet import reactor

class Echoer(pb.Root):
    def remote_echo(self, st):
        print 'echoing:', st
        return st

if __name__ == '__main__':
    reactor.listenTCP(8789, pb.PBServerFactory(Echoer()))
    reactor.run()
