#!/usr/bin/env python
# twisted_pop3client.py -- Fetch mails from a POP3 mailbox

from getpass import getpass

SERVER = raw_input("POP3 Server: ")
USER   = raw_input("POP3 User: ")
PASSWD = getpass("POP3 Password: ")
DEBUG  = True

from twisted.internet import defer, reactor, ssl
from twisted.internet.protocol import ClientCreator
from twisted.mail.pop3client import POP3Client

def cb_success(response):
    if DEBUG: print 'OK', response
    return response
def cb_error(error):
    print 'ERR', error;
    reactor.stop()
                
def cb_start(pop3Client):
    if DEBUG: print "cb_start()"
    dlogin = pop3Client.login(USER, PASSWD)
    dlogin.addCallbacks(cb_stat, cb_error, callbackArgs=(pop3Client,))

def cb_stat(result, pop3Client):
    if DEBUG: print "cb_stat()"
    dstat = pop3Client.stat()
    dstat.addCallbacks(cb_list, cb_error, callbackArgs=(pop3Client,))

def cb_list(result, pop3Client):
    if DEBUG: print "cb_list(). stat() returned:", result
    dlist = pop3Client.listSize()
    dlist.addCallbacks(cb_fetchall, cb_error, callbackArgs=(pop3Client,))

def cb_fetchall(result, pop3Client):
    if DEBUG: print "cb_fetchall(). listSize() returned:", result
    fetchers = []
    for idx in range(len(result)):
        dmesg = pop3Client.retrieve(idx)
        dmesg.addCallbacks(cb_gotmessage, cb_error)
        fetchers.append(dmesg)
    metadef = defer.DeferredList(fetchers)
    metadef.addCallbacks(cb_gotall, cb_error, callbackArgs=(pop3Client,))

def cb_gotmessage(result):
    if DEBUG: print "cb_gotmessage()"
    print "\n".join(result)

def cb_gotall(result, pop3Client):
    if DEBUG: print "cb_gotall(). global result:", result
    dquit = pop3Client.quit()
    dquit.addCallbacks(lambda _: reactor.stop(), cb_error)

client = ClientCreator(reactor, POP3Client)
dmain = client.connectSSL(SERVER, 995, ssl.ClientContextFactory())
dmain.addCallbacks(cb_success, cb_error)
dmain.addCallbacks(cb_start, cb_error)
reactor.run()
