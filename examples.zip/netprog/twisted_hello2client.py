#!/usr/bin/env python
# twisted_hello2client.py -- A chatty hello, world client in Twisted

from twisted.internet.protocol import ClientFactory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor
from sys import stdout

class ChattyClientHelloWorld(LineReceiver):
    "A Chatty Hello World client-side Protocol"
    
    def __init__(self):
        self.state = 0    # 0: waiting for prompt, 1: waiting for greeting
    
    def lineReceived(self, line):
        "Got a line from the server. Act according to self.state"
        
        self.line = line
        
        if self.state == 0:
            # Got prompt from server: reply by sending name
            try:
                self.name = raw_input(self.line + " ")
                self.sendLine(self.name)
            except EOFError:
                self.sendLine("User didn't answer")
            finally:
                self.state = 1
        
        elif self.state == 1:
            # Got greeting from server: print out, and close conn
            stdout.write(self.line + "\r\n")
            self.transport.loseConnection()
            self.state = 2
        
        else:
            # Should not happen. Got spurious line
            stdout.write("Got spurious line: " + self.line + "\r\n")
            self.transport.loseConnection()

class ChattyClientFactoryHelloWorld(ClientFactory):
    "A Factory for ChattyClientHelloWorld protocol"
    
    protocol = ChattyClientHelloWorld
    
    def clientConnectionLost(self, connector, reason):
        reactor.stop()
    
    def clientConnectionFailed(self, connector, reason):
        reactor.stop()

def start_client(host='localhost', port=7111):
    "Start client protocol on this port"
    
    reactor.connectTCP(host, port, ChattyClientFactoryHelloWorld())
    reactor.run()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "host port"
        sys.exit(1)
    host, port = sys.argv[1], int(sys.argv[2])
    
    start_client(host, port)
