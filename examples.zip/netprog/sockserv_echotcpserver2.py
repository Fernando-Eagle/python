#!/usr/bin/env python
# sockserv_echotcpserver2.py -- A simple TCP echo server with SocketServer

from SocketServer import ThreadingTCPServer, StreamRequestHandler

class EchoHandler(StreamRequestHandler):
    def handle(self):
        print "Serving client:", self.client_address
        for line in (self.rfile):
            self.wfile.write("S:" + line)

ThreadingTCPServer.allow_reuse_address = True
srv = ThreadingTCPServer(('', 7070), EchoHandler)
srv.serve_forever()
