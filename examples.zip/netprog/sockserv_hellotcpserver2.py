#!/usr/bin/env python
# sockserv_hellotcpserver2.py -- A simple TCP hello server with SocketServer

from SocketServer import TCPServer, StreamRequestHandler

class HelloHandler(StreamRequestHandler):
    def handle(self):
        print "Serving client:", self.client_address
        self.wfile.write('Hello Client! I am a HelloHandler\r\n')

TCPServer.allow_reuse_address = True
srv = TCPServer(('', 7070), HelloHandler)
srv.serve_forever()
