#!/usr/bin/env python
# twisted_fetcher2.py -- fetch and display a page via HTTP using Deferred.

from twisted.internet import reactor
from twisted.web.client import getPage
import sys

def removeAds(thepage):
    "This would remove all Ads from a page"
    return thepage    # Not yet implemented

def contentHandler(thepage):
    print thepage,
    reactor.stop()

def errorHandler(theerror):
    print theerror
    reactor.stop()

d = getPage(sys.argv[1])
d.addCallback(removeAds)
d.addCallback(contentHandler)
d.addErrback(errorHandler)

reactor.run()
