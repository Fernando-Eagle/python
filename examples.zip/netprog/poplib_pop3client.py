#!/usr/bin/env python
# poplib_pop3client.py -- Fetch mail headers from a POP3 mailbox

from getpass import getpass

SERVER = raw_input("POP3 Server: ")
USER   = raw_input("POP3 User: ")
PASSWD = getpass("POP3 Password: ")
DEBUG  = True

from poplib import POP3_SSL as POP3

pop3 = POP3(SERVER)
print pop3.getwelcome()

pop3.user(USER)
pop3.pass_(PASSWD)

print "New messages: %d, total size of mailbox: %d" % pop3.stat()

response, mlist, octets = pop3.list()
print "Response code to list: %s. Octets: %d" % (response, octets)

for mentry in mlist:
    msg_num, size = mentry.split()
    response, headers, octets = pop3.top(msg_num, 0)
    for hdr in headers:
        if 'Subject' in hdr:
            print msg_num, hdr

pop3.quit()
