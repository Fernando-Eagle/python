class TagCounter(object):
    def startDocument(self):
        self.tagCount = {}
    
    def startElementNS(self, name, qname, attribs):
        if name in self.tagCount:
            self.tagCount[name] += 1
        else:
            self.tagCount[name] = 1
