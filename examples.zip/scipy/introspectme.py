#!/usr/bin/env python
# introspectme.py -- helper functions to inspect large modules

import inspect

def modules(module):
    "Returns a list of submodules of module"
    return [m[0] for m in inspect.getmembers(module)
            if inspect.ismodule(m[1]) ]

def functions(module):
    "Returns a list of functions of module"
    return [m[0] for m in inspect.getmembers(module)
            if inspect.isfunction(m[1])]
