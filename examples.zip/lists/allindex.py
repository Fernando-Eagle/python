#!/usr/bin/env python
# allindex.py -- an iterated list.index function.

def allindex(the_list, the_value):
    "Compute a list of all indexes of the_value within the_list."
    indexes = []
    try:
        search_from_here = 0
        while True:
            found_index = the_list.index(the_value, search_from_here)
            indexes.append(found_index)
            search_from_here = found_index + 1
    except ValueError:
        return indexes

if __name__ == '__main__':
    assert allindex([111, 222, 333, 222, 444, 555], 222) == [1, 3]
    assert allindex([111, 222, 333, 222, 444, 555], 999) == []
    assert allindex([], 111) == []
