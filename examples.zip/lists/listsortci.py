#!/usr/bin/env python
# listsortci.py -- sort list case-insensitively

def ci_compare(x, y):
    "Compare two strings case-insensitively"
    return cmp(x.lower(), y.lower())

def ci_compare_verbose(x, y):
    "Compare two strings case-insensitively"
    x_lower, y_lower = x.lower(), y.lower()
    if x_lower < y_lower: return -1
    elif x_lower > y_lower: return 1
    else: return 0

L = 'The Quick Brown Fox Jumped over the Lazy Dog'.split()
L1, L2, L3, L4, L5 = L[:], L[:], L[:], L[:], L[:]  # Create copies of L

L1.sort(cmp=ci_compare)
L2.sort(cmp=ci_compare_verbose)
L3.sort(cmp=lambda x,y: cmp(x.lower(), y.lower()))
L4.sort(key=str.lower)
L5.sort(key=lambda x: x.lower())

print L1
print L2
print L3
print L4
print L5

# Output in all five cases:
# ['Brown', 'Dog', 'Fox', 'Jumped', 'Lazy', 'over', 'Quick', 'The', 'the']
