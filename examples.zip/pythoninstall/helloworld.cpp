// helloworld.cpp -- Hello, World in C++

#include <iostream>

int main()
{
  std::cout << "Hello, World!" << std::endl;
}
