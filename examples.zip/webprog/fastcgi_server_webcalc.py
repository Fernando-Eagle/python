#!/usr/bin/env python
# fastcgi_server_webcalc.py -- A FastCGI server with a WSGI web calculator

from flup.server.fcgi import WSGIServer
from wsgicalc import webcalc

wsgi = WSGIServer(webcalc, bindAddress=('', 20000))
wsgi.run()
