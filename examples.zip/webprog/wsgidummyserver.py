#!/usr/bin/env python
# wsgidummyserver.py -- a pseudo-server that calls a WSGI application.

class WSGIDummyServer(object):
    "A dummy server that calls a WSGI application"

    def __init__(self, app):
        self.app = app
        self.app.iterable = None
        self.client = None

    def handle_request(self, client):
        "Handle a request by a client. client is a file-like object"

        print "S: handle_request() called"
        
        self.client = client

        # The following environment is NOT WSGI-conform!
        # It's missing CGI- and wsgi.* values required by the spec.
        environment = { 'CLIENT': client }

        print 'S: About to call application with arguments:'
        print 'S:   environ:', environment
        print 'S:   start_response:', self.my_start_response
        self.app.iterable = self.app(environment, self.my_start_response)

        print 'S: Finished calling application. Got iterable back.'

        for chunk in self.app.iterable:
            print "S: got a chunk from app:"
            print "S:   chunk was:", chunk
            print "S: sending chunk to client"
            self.client.write(chunk)

        print 'S: Got all chunks from app iterator. Closing client conn.'
        
        # A real webserver would close the connection to the client here.
        # self.client.close()
        self.client = None
        self.app.iterable = None

    def my_start_response(self, status, response_headers):
        "Send initial headers back to client"

        print "S: my_start_response() called"

        self.client.write(status + "\r\n")
        for key, value in response_headers:
            self.client.write("%s=%s\r\n" % (key, value))
        self.client.write("\r\n")
