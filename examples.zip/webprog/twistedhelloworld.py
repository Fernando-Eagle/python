#!/usr/bin/env python
# twistedhelloworld.py -- A simple hello, world Twisted.Web server.
# From: Twisted.Web HowTo "Configuring and Using the Twisted.Web server"

from twisted.web import server, resource
from twisted.internet import reactor

class HelloWorld(resource.Resource):
    
    isLeaf = True
    
    def render_GET(self, request):
        return "<html>Hello, world.</html>"

if __name__ == '__main__':
    site = server.Site(HelloWorld())
    reactor.listenTCP(9090, site)
    reactor.run()
