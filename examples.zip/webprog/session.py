#!/usr/bin/env python
# session.py -- abstract class representing a server-side session

class BaseSession(object):
    "Abstract class represending a server-side session"
    def __init__(self, session_time=3600):
        "Initialize database connections etc. here. Don't forget to call me"
        self.expires_interval = session_time

    def close(self):
        "Close database connections here"
        raise NotImplementedError('Method must be implemented by subclass')

    def session_create(self, user_id):
        "Create a new session for user user_id. Return new session_id"
        raise NotImplementedError('Method must be implemented by subclass')

    def session_remove(self, session_id):
        "Remove the session with the ID session_id"
        raise NotImplementedError('Method must be implemented by subclass')

    def session_valid(self, session_id):
        "Verify that the session is still valid by checking its expire time"
        raise NotImplementedError('Method must be implemented by subclass')

    def session_extend_time(self, session_id):
        "Extend the expire time by self.expires_interval"
        raise NotImplementedError('Method must be implemented by subclass')
