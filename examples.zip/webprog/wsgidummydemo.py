#!/usr/bin/env python
# wsgidummydemo.py -- show interaction between WSGIDummyServer and MyApp

from wsgidummyapp import WSGIDummyApp
from wsgidummyserver import WSGIDummyServer
from cStringIO import StringIO

app    = WSGIDummyApp()
server = WSGIDummyServer(app)
client = StringIO()

server.handle_request(client)

print '-' * 70
print 'Client got the following reply:'
print client.getvalue()
