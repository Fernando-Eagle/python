#!/usr/bin/env python
# session_dbapi.py -- server-side sessions using DB-API 2.0

'''
session_dbapi.py implements a session.BaseSession on PostgreSQL.
It assumes a table "session" that has been defined as follows:

CREATE TABLE sessions (
    session_id BIGSERIAL PRIMARY KEY,
    user_id    VARCHAR(8),
    expires    INTEGER
);
'''

import time
import psycopg2
import session

def now():
    return int(time.time())

class DBSession(session.BaseSession):
    "A server-side session saved in a DB-API 2.0 table"
    def __init__(self, dsn, session_time=3600):
        super(DBSession, self).__init__(session_time)
        self.dsn = dsn
        self.conn = psycopg2.connect(dsn)
        self.curs = self.conn.cursor()

    def close(self):
        self.curs.close()
        self.conn.close()
        self.conn = self.curs = None
        
    def session_create(self, user_id):
        "Create a new session for user user_id. Return new session_id"
        data = { 'user_id': user_id,
                 'expires': now() + self.expires_interval }
        self.curs.execute("INSERT INTO sessions ( user_id, expires ) "
                          "VALUES ( '%(user_id)s', %(expires)d )" %
                          data)
        self.curs.execute("SELECT currval('sessions_session_id_seq')")
        session_id = self.curs.fetchone()[0]
        self.conn.commit()
        return session_id

    def session_remove(self, session_id):
        "Remove the session with the ID session_id"
        data = { 'session_id': session_id }
        self.curs.execute("DELETE FROM sessions "
                          "WHERE session_id = %(session_id)s" %
                          data)
        self.conn.commit()

    def session_valid(self, session_id):
        "Verify that the session is still valid by checking its expire time"
        data = { 'session_id': session_id }
        self.curs.execute("SELECT expires FROM sessions "
                          "WHERE session_id = %(session_id)d" %
                          data)
        expires = self.curs.fetchone()[0]
        return now() <= expires

    def session_extend_time(self, session_id):
        "Extend the expire time by self.expires_interval"
        data = { 'session_id': session_id,
                 'expires'   : now() + self.expires_interval }
        self.curs.execute("UPDATE sessions SET expires = %(expires)d "
                          "WHERE session_id = %(session_id)d" %
                          data)
        self.conn.commit()
