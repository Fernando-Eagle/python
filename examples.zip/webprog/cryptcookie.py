#!/usr/bin/env python
# cryptcookie.py -- An encrypted and signed Cookie class

from base64 import b64encode, b64decode
import Cookie
import cryptutils

class ModifiedCookieError(Exception): pass

class CryptCookie(Cookie.BaseCookie):
    "A collection of cookies that are encrypted and signed"
    
    def __init__(self, serverkey):
        super(CryptCookie, self).__init__()
        self.serverkey = serverkey

    def value_encode(self, val):
        data, pad_size = cryptutils.pad(str(val), 16, ' ')
        cyphertext     = cryptutils.Encrypt(data, self.serverkey)
        signature      = cryptutils.HMAC(data, self.serverkey)     # 64 bytes!
        message        = b64encode(cyphertext + signature)
        return val, message

    def value_decode(self, val):
        recvmsg        = b64decode(val)
        cyphertext     = recvmsg[:-64]
        signature      = recvmsg[len(recvmsg)-64:]
        plaintext      = cryptutils.Decrypt(cyphertext, self.serverkey)
        if cryptutils.HMAC(plaintext, self.serverkey) != signature:
            raise ModifiedCookieError()
        return plaintext, val    # plaintext is probably still padded!
