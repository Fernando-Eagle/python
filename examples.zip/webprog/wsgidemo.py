#!/usr/bin/env python
# wsgidemo.py -- Running the WSGI-Demo within a WSGI-enabled webserver
# From: Python Library Reference, 18.4.3 wsgiref.simple_server, make_server()

from wsgiref.simple_server import make_server, demo_app

server = make_server('', 9090, demo_app)
server.serve_forever()
