#!/usr/bin/env python
# cherrypysite.py -- a web site with many different parts

import cherrypy

class Rootsite(object):
    @cherrypy.expose
    def index(self): return "Rootsite.index()\r\n"

    @cherrypy.expose
    def default(self, *args): return "Rootsite.default(%s)\r\n" % str(args)

class Forum(object):
    @cherrypy.expose
    def index(self): return "Forum.index()\r\n"
    
    @cherrypy.expose    
    def default(self, *args): return "Forum.default(%s)\r\n" % str(args)

    @cherrypy.expose
    def admin(self, *args): return "Forum.admin(%s)\r\n" % str(args)

class Archive(object):
    @cherrypy.expose
    def index(self): return "Archive.index()\r\n"

    @cherrypy.expose
    def default(self, *args): return "Archive.default(%s)\r\n" % str(args)

if __name__ == '__main__':
    rootsite = Rootsite()
    rootsite.talkback = Forum()
    rootsite.newsroom = Archive()
    cherrypy.quickstart(rootsite, config='cherrypy.cfg')
