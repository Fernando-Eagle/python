#!/usr/bin/env python
# wsgicalc.py -- A web calculator as WSGI application

def webcalc(environ, start_response):
    "A web calculator as WSGI application"
    from cStringIO import StringIO
    out = StringIO()

    def send_result(result):
        print >>out, result + "\r\n"
        start_response("200 OK", [('Content-Type', 'text/plain')])

    path = environ.get('PATH_INFO', None)
    if path is None:
        send_result("Usage: /{add,sub,mul,div}/num1/num2")
        return [out.getvalue()]

    lst = path.split('/')
    if len(lst) != 4:
        send_result("Invalid syntax. Use /op/arg1/arg2")
        return [out.getvalue()]
    
    dummy, op, arg1, arg2 = lst
    if op not in ('add', 'sub', 'mul', 'div'):
        send_result("Invalid operator. Use one of add, sub, mul, div.")
        return [out.getvalue()]

    try:
        numarg1 = float(arg1)
        numarg2 = float(arg2)
    except ValueError:
        send_result("Invalid numerical argument.")
        return [out.getvalue()]

    if op == 'add': result = numarg1 + numarg2
    elif op == 'sub': result = numarg1 - numarg2
    elif op == 'mul': result = numarg1 * numarg2
    elif op == 'div':
        if numarg2 == 0: result = 'N/A'
        else:            result = numarg1 / numarg2
    send_result(str(result))
    return [out.getvalue()]

def run(port):
    "Start the WSGI server"
    from wsgiref.simple_server import make_server
    server = make_server('', port, webcalc)
    server.serve_forever()

if __name__ == '__main__':
    run(9090)
