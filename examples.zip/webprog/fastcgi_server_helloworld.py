#!/usr/bin/env python
# fastcgi_server_helloworld.py -- A FastCGI server with a WSGI-App.

from flup.server.fcgi import WSGIServer

def hello_app(environ, start_response):
    "A simple WSGI application"
    start_response("200 OK", [('Content-Type', 'text/plain')])
    return ["Hello, I am a WSGI application"]

wsgi = WSGIServer(hello_app, bindAddress="/tmp/lighttpd_test_fastcgi.sock")
wsgi.run()
