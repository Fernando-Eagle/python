#!/usr/bin/env python
# basehttpserver2.py -- a basic HTTP server without GET method.

import BaseHTTPServer

class MyHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        print "Got GET Request from", self.client_address
        self.wfile.write('Sorry, I do not speak HTTP. Go away.\r\n')

server_address = ('', 9090)
handler_class  = MyHandler
server_class   = BaseHTTPServer.HTTPServer

server = server_class(server_address, handler_class)
server.serve_forever()
