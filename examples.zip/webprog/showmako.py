#!/usr/bin/env python
# showmako.py -- render mako templates

from mako.template import Template
from mako.lookup import TemplateLookup

class Renderer(object):
    def __init__(self, dirs='.', moddir='/tmp/mako'):
        self.lookup = TemplateLookup(directories=dirs,
                                     module_directory=moddir)
    def render(self, templatename, **kwargs):
        self.tmpl = self.lookup.get_template(templatename)
        return self.tmpl.render(**kwargs)
    def render_unicode(self, templatename, **kwargs):
        self.tmpl = self.lookup.get_template(templatename)
        return self.tmpl.render_unicode()

if __name__ == '__main__':
    import sys
    r = Renderer('.', '/tmp/mako')
    print r.render(sys.argv[1]),
