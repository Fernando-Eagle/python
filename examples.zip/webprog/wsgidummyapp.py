# wsgidummyapp.py -- an object oriented WSGI-like application class

class WSGIDummyApp(object):
    def __call__(self, environ, start_response):
        "Called by WSGI-enabled server"

        output = []

        # The following print statements are not WSGI-conform!
        # Don't write to sys.stdout from within a WSGI application!
        print 'C: I have been called with arguments:'
        print 'C:    environ: %r' % (environ,)
        print 'C:    start_response: %r' % (start_response,)

        if 'CLIENT' in environ:
            output.append("Hello Client %r\n" % (environ['CLIENT'],))
        else:
            output.append("Hello WSGI World\n")
        output.append("Nice to meet you\n")
        output_length = str(len(''.join(output)))

        print 'C: I will call start_response now'
        start_response('200 OK', [('Content-type', 'text/plain'),
                                  ('Content-Length', str(len(output)))])

        print 'C: Finished calling start_response'
        print 'C: now, returning output iterable'
        return output
