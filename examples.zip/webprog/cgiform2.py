#!/usr/bin/env python
# cgiform2.py -- decode form data from CGI using the cgi module

import cgitb; cgitb.enable()
import cgi

print "Content-type: text/html"
print

result = []
result.append("<html><head><title>Results</title></head><body>")
result.append("<ul>")

form = cgi.FieldStorage()
for field in form.keys():
    valuelist = form.getlist(field)
    for value in valuelist:
        result.append("<li>%s: %s</li>" %
                      (cgi.escape(field), cgi.escape(value)))

result.append("</ul></body></html>")
print '\n'.join(result)
