from django.template import Context, loader
from django.http import HttpResponse
from django.shortcuts import render_to_response

from pypost.articles.models import Article, Talkback

def index(request):
    "Create a list of the 5 latest articles"
    latest_articles_list = Article.objects.all().order_by('-pub_date')[:5]
    t = loader.get_template('articles/index.html')
    c = Context({'latest_articles_list': latest_articles_list,})
    return HttpResponse(t.render(c))

def article(request, article_id):
    "Fetch and show the article with the ID article_id and its talkback list"
    article = Article.objects.get(pk=article_id)
    talkbacks = article.talkback_set.all()
    return render_to_response('articles/article.html',
                              {'article': article, 'talkbacks': talkbacks})

def talkback(request, article_id, talkback_id):
    "Fetch and show a talkback to an article"
    talkback = Talkback.objects.get(pk=talkback_id)
    article  = Article.objects.get(pk=article_id)
    article_title = article.title
    return render_to_response('articles/talkback.html',
                              {'article_title': article_title,
                               'article_id': article_id,
                               'talkback': talkback})

def newtalkback(request, article_id):
    "Present a form for a new talkback to article_id"
    article = Article.objects.get(pk=article_id)
    article_title = article.title
    return render_to_response('articles/newtalkback.html',
                              {'article_title': article_title,
                               'article_id': article_id})

def savetalkback(request, article_id):
    "Saved user-submitted talkback data"
    art = Article.objects.get(pk=article_id)
    art.talkback_set.create(tbauthor=request.POST['author'],
                            tbemail=request.POST['email'],
                            tbloc=request.POST['location'],
                            tbsubject=request.POST['subject'],
                            tbcontent=request.POST['content'])
    return article(request, article_id) # Display article page again.

