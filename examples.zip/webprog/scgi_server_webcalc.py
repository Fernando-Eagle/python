#!/usr/bin/env python
# scgi_server_webcalc.py -- A SCGI server with a WSGI web calculator

from flup.server.scgi import WSGIServer
from wsgicalc import webcalc

wsgi = WSGIServer(webcalc, bindAddress=('', 21000))
wsgi.run()
