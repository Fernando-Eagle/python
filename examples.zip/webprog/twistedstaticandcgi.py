#!/usr/bin/env python
# twistedstaticandcgi.py -- A Twisted.Web static file server with cgi support

from twisted.web import server, static, twcgi
from twisted.internet import reactor

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, \
              "Usage: %s /static/path/to/serve /cgi/path/to/serve" % \
              (sys.argv[0],)
        sys.exit(1)
    
    root = static.File(sys.argv[1])
    root.putChild('cgi-bin', twcgi.CGIDirectory(sys.argv[2]))
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
