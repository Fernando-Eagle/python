print "Content-Type: text/plain\r\n";
print "\r\n";

print "I am a perl script\r\n";
