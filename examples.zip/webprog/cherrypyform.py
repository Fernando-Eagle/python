#!/usr/bin/env python
# cherrypyform.py -- read data from a form

import cherrypy

class FeedbackForm(object):
    @cherrypy.expose
    def feedback(self, username=None, email=None):
        if username is None or email is None:
            return self.send_form()
        else:
            return "Got username: %s, Email: %s" % (username, email)

    def send_form(self):
        return '''<div>
  <form action="/feedback" method="POST">
    <p>Username: <input type="text" name="username" size="40"/></p>
    <p>Email:    <input type="text" name="email" size="40"/></p>
    <p><input type="submit" value="Send"/>
       <input type="reset" value="Clear"/>
    </p>
  </form>
</div>'''

if __name__ == '__main__':
    feedback = FeedbackForm()
    cherrypy.quickstart(feedback, config='cherrypy.cfg')
