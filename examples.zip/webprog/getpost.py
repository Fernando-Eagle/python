#!/usr/local/bin/python
# getpost.cgi -- receive a HTTP GET or HTTP POST request.

import cgi
import cgitb; cgitb.enable()

print "Content-type: text/plain\n"

form = cgi.FieldStorage()
if not "firstname" in form and not "lastname" in form:
    print "Please fill in firstname and lastname fields"
else:
    print "Hello,", form['firstname'].value, form['lastname'].value
