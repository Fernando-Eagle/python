#!/usr/bin/env python
# cgiupload.py -- CGI to upload a file to a directory on the webserver.

import cgitb; cgitb.enable()
import cgi
import sys, os.path

DESTDIR   = '/tmp'           # CHANGE ME!
PASSWORD  = 'smurf32ii'      # CHANGE ME!
BLOCKSIZE = 4096

FORMTEXT  = '''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>A simple file upload form</title>
  </head>
  <body>
    <h1>Upload a file to %(destdir)s</h1>
    <form action="%(action)s" method="POST"
          enctype="multipart/form-data">
      <input type="file" name="filename" />(File Name)<br />
      <input type="password" size="8" name="password" /> (User Password)<br />
      <input type="submit" value="Upload file"/>
    </form>
  </body>
</html>''' % { 'destdir': DESTDIR,
               'action': os.environ.get('SCRIPT_NAME', 'not-a-cgi') }

def bailout(result):
    result.append('</body></html>')
    print '\n'.join(result)
    sys.exit(0)

print "Content-type: text/html"
print

result = []    # HTML reply
result.append('<html><head><title>Upload result</title></head><body>')

form = cgi.FieldStorage()
if 'filename' not in form:
    # User didn't send anything yet.
    print FORMTEXT
    sys.exit(0)
    
try:
    filename = form['filename'].filename
    password = form['password'].value
except:
    result.append('<p>Filename or password missing. Nothing uploaded.</p>')
    result.append('</body></html>')
    bailout(result)

if password != PASSWORD:
    result.append('<p>Wrong password. Nothing uploaded.</p>')
    result.append('</body></html>')
    bailout(result)

# Sanitize (somewhat) output filename
outfilename = filename.replace(os.path.sep, '_').replace(os.path.pardir, '_')
outfilename = os.path.join(DESTDIR, outfilename)

# Now copy chunkwise from form['filename'].file to outfilename
nbytes = 0L
f_inp = form['filename'].file
f_out = open(outfilename, 'wb')
while (True):
    chunk = f_inp.read(BLOCKSIZE)
    if not chunk: break
    f_out.write(chunk)
    nbytes += len(chunk)
f_out.close()
f_inp.close()

# That's all, folks!
result.append('<p>Uploaded %d bytes from %s to %s</p>' %
              (nbytes, filename, outfilename))
bailout(result)
