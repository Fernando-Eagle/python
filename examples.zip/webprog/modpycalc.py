#!/usr/bin/env python
# modpycalc.py -- A webcalc handler for mod_python.

def add(req, arg1=None, arg2=None):
    req.content_type = 'text/plain'
    if arg1 is None or arg2 is None:
        return "Wrong syntax. Use /add/arg1/arg2"
    try:
        numarg1 = float(arg1)
        numarg2 = float(arg2)
    except ValueError:
        return "Non numerical operands"
    result = numarg1 + numarg2
    return str(result)
