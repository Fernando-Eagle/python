#!/usr/bin/env python
# twistedurl2.py -- A Twisted.Web with two attached resources.

from twisted.web import server, resource
from twisted.internet import reactor

class DynamicResource(resource.Resource):
    isLeaf = True
    def render_GET(self, request):
        return "I am a dynamic resource.\r\n" \
               "request.prepath=%r, request.postpath=%r\r\n" % \
               (request.prepath, request.postpath)

if __name__ == '__main__':
    root = resource.Resource()
    root.putChild('talkback', DynamicResource())
    root.putChild('newsroom', DynamicResource())
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
