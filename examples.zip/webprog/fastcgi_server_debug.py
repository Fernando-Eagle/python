#!/usr/bin/env python
# fastcgi_server_debug.py -- A FastCGI server with a WSGI-App.

from cStringIO import StringIO
from pprint import pformat

from flup.server.fcgi import WSGIServer

def debug_app(environ, start_response):
    "A simple WSGI debug application"
    
    buf = StringIO()
    print >>buf, 'WSGI application received environ:\r\n'
    print >>buf, pformat(environ), '\r\n'
    
    start_response("200 OK", [('Content-Type', 'text/plain')])
    return [buf.getvalue()]

wsgi = WSGIServer(debug_app, bindAddress=('', 20000))
wsgi.run()
