#!/usr/bin/env python
# cgihello.py -- Hello, CGI World.

from sys import stdout

stdout.write("Content-type: text/plain\r\n")
stdout.write("\r\n")
stdout.write("Hello, CGI World!\r\n")
