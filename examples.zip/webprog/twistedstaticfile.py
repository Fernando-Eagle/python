#!/usr/bin/env python
# twistedstaticfile.py -- A Twisted.Web static file server.

from twisted.web import server, static
from twisted.internet import reactor

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage: %s /path/to/serve" % (sys.argv[0],)
        sys.exit(1)
    
    root = static.File(sys.argv[1])
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
