from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^articles/$',                     'pypost.articles.views.index'),
    (r'^articles/(?P<article_id>\d+)/$', 'pypost.articles.views.article'),
    (r'^articles/(?P<article_id>\d+)/(?P<talkback_id>\d+)/$',
                                         'pypost.articles.views.talkback'),
    (r'^articles/(?P<article_id>\d+)/talkback/$',
                                         'pypost.articles.views.newtalkback'),
    (r'^articles/(?P<article_id>\d+)/talkback_submit/$',
                                         'pypost.articles.views.savetalkback'),

    (r'^admin/', include('django.contrib.admin.urls')),
)
