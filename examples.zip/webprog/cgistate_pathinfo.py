#!/usr/bin/env python
# cgistate_pathinfo.py -- Preserving CGI state with PATH_INFO

import cgitb; cgitb.enable()
import os, os.path

def state_fetch():
    try:
        state = int(os.environ.get('PATH_INFO', '/1')[1:])
    except ValueError:
        state = 1
    finally:
        return state

def state_update(state):
    state = state + 1
    return state

def state_store(state):
    if 'SCRIPT_NAME' not in os.environ:
        return "This is not a CGI script. Can't call again."
    else:
        return 'Call me <a href="%s/%d">again</a><br />' % \
               (os.environ['SCRIPT_NAME'], state)

print "Content-type: text/html"
print

result = []
result.append('<html><head><title>Counter 1</title></head></body><p>')

# Fetch old counter value from client
oldstate = state_fetch()
result.append('Old Counter: %d<br />' % (oldstate,))

# Compute new counter value
newstate = state_update(oldstate)
result.append('New Counter: %d<br />' % (newstate,))

# Send new counter value to client
result.append(state_store(newstate))

result.append('</p></body></html>')
print '\n'.join(result)
