<?php
   print "Content-Type: text/plain\r\n";
   print "\r\n";
   phpinfo();
?>
