#!/usr/bin/env python
# showgenshi.py -- render genshi templates

from genshi.template import TemplateLoader, MarkupTemplate

class Renderer(object):
    def __init__(self, dirs='.', variable_lookup='strict'):
        self.loader = TemplateLoader(dirs, variable_lookup=variable_lookup)
        self.variable_lookup = variable_lookup
    
    def r_file(self, templatename, **kwargs):
        self.tmpl = self.loader.load(templatename)
        self.stream = self.tmpl.generate(**kwargs)
        return self.stream.render('xhtml')
    
    def r_str(self, templatestring, **kwargs):
        self.tmpl = MarkupTemplate(templatestring,
                                   lookup=self.variable_lookup)
        self.stream = self.tmpl.generate(**kwargs)
        return self.stream.render('xhtml')
    
if __name__ == '__main__':
    import sys
    r = Renderer('.')
    print r.render(sys.argv[1]),
