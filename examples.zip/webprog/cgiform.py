#!/usr/bin/env python
# cgiform.py -- decode form data from CGI

import os, sys, urllib

reqmeth = os.environ['REQUEST_METHOD']

if reqmeth == 'GET':
    data = os.environ['QUERY_STRING']
elif reqmeth == 'POST':
    data = sys.stdin.read()
else:
    data = "Unknown method %s. Must be GET or POST" % (reqmeth)

sys.stdout.write('Content-type: text/plain\r\n\r\n')
sys.stdout.write('Got the following data with %s method:\r\n' % (reqmeth,))
sys.stdout.write(data + '\r\n\r\n')

sys.stdout.write('Partially decoding fields:\r\n')
fields = data.split('&')
for field in fields:
    fieldname, fieldvalue = field.split('=')
    sys.stdout.write(' ' + fieldname + ': ' + fieldvalue + '\r\n')
