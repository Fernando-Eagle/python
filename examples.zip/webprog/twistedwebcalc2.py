#!/usr/bin/env python
# twistedwebcalc2.py -- A Twisted.Web calculator resource.

from twisted.web import server, resource
from twisted.internet import reactor
from twistedwebcalc import WebCalc

if __name__ == '__main__':
    root = resource.Resource()
    root.putChild('calc', WebCalc())

    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
