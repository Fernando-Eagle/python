#!/usr/bin/env python
# cryptutils.py -- crypto utility functions

import Crypto.Cipher.AES
import hmac, hashlib

def HMAC(data, key):
    """HMAC
    Compute the HMAC algorithm of RFC 2104 on DATA using the key KEY
    and the digest algorithm SHA-256.
    Return the compute HMAC as string.
    """
    hmacer = hmac.HMAC(key, digestmod=hashlib.sha256)
    hmacer.update(data)
    return hmacer.hexdigest()

def Encrypt(data, key):
    """Encrypt
    Encrypt DATA with KEY using the AES algorithm in ECB mode.
    KEY must be 16, 24, or 32 bytes long. DATA must be a multiple
    of 16 in length.
    Return a the encrypted text.
    """
    encrypter = Crypto.Cipher.AES.new(key, Crypto.Cipher.AES.MODE_ECB)
    return encrypter.encrypt(data)

def Decrypt(data, key):
    """Decrypt
    Decrypt DATA with KEY using the AES algorithm in ECB mode.
    KEY must be 16, 24, or 32 bytes long. DATA must be a multiple
    of 16 in length.
    Return the decrypted data as string.
    """
    decrypter = Crypto.Cipher.AES.new(key, Crypto.Cipher.AES.MODE_ECB)
    return decrypter.decrypt(data)

def pad(data, padlength=16, padbyte='\x00'):
    padsize = padlength - (len(data) % padlength)
    padded = data + padbyte * padsize
    return padded, padsize

def unpad(data, padsize=0):
    return data[:-padsize]
