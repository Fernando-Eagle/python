#!/usr/bin/env python
# cherrypycalc.py -- web calculator using CherryPy

import cherrypy

class Calculator(object):
    @cherrypy.expose
    def add(self, arg1, arg2):
        return self.calculate('add', arg1, arg2)

    @cherrypy.expose
    def sub(self, arg1, arg2):
        return self.calculate('sub', arg1, arg2)

    @cherrypy.expose
    def mul(self, arg1, arg2):
        return self.calculate('mul', arg1, arg2)

    @cherrypy.expose
    def div(self, arg1, arg2):
        return self.calculate('div', arg1, arg2)

    @cherrypy.expose
    def default(self, *args):
        return "Invalid operator. Use one of 'add', 'sub', 'mul', or 'div'"

    def calculate(self, op, arg1, arg2):
        # if op not in ('add', 'sub', 'mul', 'div'):
        #     return "Invalid operator. Use 'add', 'sub', 'mul', or 'div'"
        result = 'No result yet'
        try:
            num1 = float(arg1)
            num2 = float(arg2)
            if op == 'add': result = num1 + num2
            elif op == 'sub': result = num1 - num2
            elif op == 'mul': result = num1 * num2
            elif op == 'div':
                if num2 == 0: result = 'NaN'
                else        : result = num1 / num2
        except ValueError:
            result = "Invalid operand. Use numerical values only."
        finally:
            return str(result)

if __name__ == '__main__':
    calc = Calculator()
    cherrypy.quickstart(calc, config='cherrypy.cfg')
