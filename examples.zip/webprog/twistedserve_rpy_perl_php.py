#!/usr/bin/env python
# twistedserve_rpy_perl_php.py -- A Twisted.Web static file server.
#                                 with .rpy, .pl und .php support

from twisted.web import server, static, script, twcgi
from twisted.internet import reactor

class PerlScript(twcgi.FilteredScript):
    filter = '/usr/bin/perl'                 # Point to the perl parser

class PHPScript(twcgi.FilteredScript):
    filter = '/usr/local/bin/php'            # Point to the PHP server

def create_server(rootpath):
    root = static.File(rootpath)
    root.processors = { '.rpy': script.ResourceScript,
                        '.pl' : PerlScript,
                        '.php': PHPScript }
    root.ignoreExt(".rpy")
    return root

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage: %s /path/to/serve" % (sys.argv[0],)
        sys.exit(1)
    
    root = create_server(sys.argv[1])
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
