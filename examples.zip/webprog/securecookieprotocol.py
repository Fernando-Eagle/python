#!/usr/bin/env python
# securecookieprotocol.py -- A Secure Cookie Protocol by Alex X. Liu et al.
# http://www.cse.msu.edu/~alexliu/publications/Cookie/cookie.pdf

'''
Pseudo code of the the Secure Cookie Protocol proposed in the paper

   A Secure Cookie Protocol
   Alex X. Liu, Jason M. Kovacs, Chin-Tser Huang, and Mohamed G. Gouda
   http://www.cse.msu.edu/~alexliu/publications/Cookie/cookie.pdf
'''

from cryptutils import Encrypt, Decrypt, HMAC
import time

def Encrypt_SCP(username, expiration_time, data, session_key, server_key):
    '''Encrypt and sign data using "A Secure Cookie Protocol."
    
    Create and return an encrypted and signed cookie payload for a
    user using a secure cookie protocol.
    
    USERNAME        is the name of the cookie owner.
    SESSION_KEY     is the SSL session ID of the Client/Server connection.
    EXPIRATION_TIME is the time in seconds since the Epoch when the
                    cookie is set to expire... as String.
    DATA            is the data to be encrypted
    SERVER_KEY      is a secret key private to the server.
    
    SCP creates a payload containing:
      USERNAME, EXPIRATION_TIME in plaintext,
      The encrypted DATA, using a key that is difficult to guess,
      a hard to forge signature.
    
    SCP uses the Encrypt and HMAC functions from cryptutils.py
    '''
    
    k = HMAC(username + expiration_time, server_key)
    C_enc = username + expiration_time + Encrypt(data, k) + \
            HMAC(username + expiration_time + data + session_key, k)
    
    return C_enc

def Decrypt_SCP(payload, session_key, server_key):
    '''Verify and decrypt payload according to "A Secure Cookie Protocol."
    
    Decrypt the cookie payload PAYLOAD and return a tuple
    (verified, decrypted_data). VERIFIED is True only if the
    payload has not been tampered with, and DECRYPTED_DATA
    contains the decrypted payload, but only if VERIFIED is True.
    
    PAYLOAD is the encrypted payload as returned by Encrypt_SCP
    SESSION_KEY is the SSL session ID of the Client/Server connection.
    SERVER_KEY  is a secret key private to the SERVER.
    
    Decrypt and HMAC are from cryptutils.py
    '''
    
    if int(payload.expiration_time) < time.time():
        return (False, None)        # Cookie expired.
    
    k         = HMAC(payload.username + payload.expiration_time, server_key)
    data      = Decrypt(payload.encrypted_data, k)
    signature =  HMAC(payload.username + payload.expiration_time + data + \
                      session_key, k)
    if computed_signature != payload.signature:
        return (False, None)        # Cookie has been tampered with
    
    return (True, data)             # Cookie is valid.
