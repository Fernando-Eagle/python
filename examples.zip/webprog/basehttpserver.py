#!/usr/bin/env python
# basehttpserver.py -- a basic HTTP server that doesn't understand GET, POST...

import BaseHTTPServer

server_address = ('', 9090)
handler_class  = BaseHTTPServer.BaseHTTPRequestHandler
server_class   = BaseHTTPServer.HTTPServer

server = server_class(server_address, handler_class)
server.serve_forever()
