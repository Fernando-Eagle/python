#!/usr/bin/env python
# fetchchunked.py -- download a URL chunkwise, write it to sys.stdout

import sys
import urllib2

BLOCKSIZE = 8192

def fetch_chunked(url, chunksize=BLOCKSIZE):
    "Fetch a 'url' to sys.stdout, using 'chunksize' bytes."

    f = urllib2.urlopen(url)
    chunk = f.read(chunksize)
    while chunk:
        sys.stdout.write(chunk)
        chunk = f.read(chunksize)
    f.close()

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print "Usage:", sys.argv[0], "URL chunksize"
        sys.exit(1)
    
    url   = sys.argv[1]
    csize = int(sys.argv[2])
    
    fetch_chunked(url, csize)
