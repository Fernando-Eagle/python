#!/usr/bin/env python
# cherrypymapper2.py -- enhanced URL-mapping to methods with CherryPy

import cherrypy

class URLMapper2(object):
    def foo(self, *args):     return "This is foo(%s)\r\n"     % str(args)
    def bar(self, *args):     return "This is bar(%s)\r\n"     % str(args)
    def index(self, *args):   return "This is index(%s)\r\n"   % str(args)
    def default(self, *args): return "This is default(%s)\r\n" % str(args)

    foo.exposed = True
    bar.exposed = True
    index.exposed = True
    default.exposed = True

if __name__ == '__main__':
    mapper = URLMapper2()
    cherrypy.quickstart(mapper, config='cherrypy.cfg')
