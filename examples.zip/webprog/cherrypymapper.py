#!/usr/bin/env python
# cherrypymapper.py -- URL-mapping to methodes with CherryPy

import cherrypy

class URLMapper(object):
    def foo(self):     return "This is foo()"
    def bar(self):     return "This is bar()"
    def index(self):   return "This is index()"
    def default(self): return "This is default()"

    foo.exposed = True
    bar.exposed = True
    index.exposed = True
    default.exposed = True

if __name__ == '__main__':
    mapper = URLMapper()
    cherrypy.quickstart(mapper, config='cherrypy.cfg')
