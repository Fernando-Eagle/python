#!/usr/bin/env python
# cherrypyhello.py -- A simple hello, world with CherryPy

import cherrypy

class Hello(object):
    @cherrypy.expose
    def index(self):
        return "Hello, CherryPy World"

if __name__ == '__main__':
    hello = Hello()
    cherrypy.quickstart(hello, config='cherrypy.cfg')
