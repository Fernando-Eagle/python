#!/usr/bin/env python
# cgicalc.py -- A web calculator using PATH_INFO

from __future__ import division
import os, sys

class WebCalculator(object):
    def add(self,a,b): return a+b
    def sub(self,a,b): return a-b
    def mul(self,a,b): return a*b
    def div(self,a,b):
        try:
            return a/b
        except ZeroDivisionError:
            return "ZeroDivisionError"

def main():
    sys.stdout.write("Content-type: text/plain\r\n\r\n")
    if 'PATH_INFO' not in os.environ:
        sys.stdout.write("Usage: cgicalc.py/{add,sub,mul,div}/a/b\r\n")
        sys.exit()

    paramlist = os.environ['PATH_INFO'].split('/')
    if len(paramlist) != 4:
        sys.stdout.write("Wrong number of parameters\r\n")
        sys.exit()

    func, arg1, arg2 = paramlist[1:]
    calc = WebCalculator()
    f = getattr(calc, func, None)
    if f is None:
        sys.stdout.write("Function %s is not defined\r\n" % (func,))
        sys.exit()

    try:
        a1 = float(arg1)
        a2 = float(arg2)
    except ValueError:
        sys.stdout.write("Arguments must be float\r\n")
        sys.exit()
            
    result = str(f(a1,a2))
    sys.stdout.write("%s(%s,%s) = %s\r\n" % (func, arg1, arg2, result))

if __name__ == '__main__':
    main()
