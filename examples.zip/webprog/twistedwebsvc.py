#!/usr/bin/env python
# twistedwebsvc.py -- Running a Twisted.Web server as a Service with twistd

from twisted.application import internet, service
from twisted.web import server, static

root = static.File("/usr/local/share/doc")

application = service.Application("web")
sc          = service.IServiceCollection(application)
site        = server.Site(root)

i = internet.TCPServer(90, site)
i.setServiceParent(sc)
