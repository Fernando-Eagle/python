from django.db import models

class Article(models.Model):
    title     = models.CharField(maxlength=100)
    slug      = models.SlugField(maxlength=50)
    pub_date  = models.DateTimeField('date published')
    author    = models.CharField('by line', maxlength=40)
    content   = models.TextField('the article')

    def __str__(self):
        return self.slug

    class Admin:
        pass

class Talkback(models.Model):
    article   = models.ForeignKey(Article)
    tbauthor  = models.CharField('tb author', maxlength=40)
    tbemail   = models.EmailField('email talkbacker')
    tbloc     = models.CharField('city or country', maxlength=20)
    tbsubject = models.CharField('subject', maxlength=40)
    tbcontent = models.CharField('the talkback', maxlength=250)

    def __str__(self):
        return self.tbsubject

    class Admin:
        pass
