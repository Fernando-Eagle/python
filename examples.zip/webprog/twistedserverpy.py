#!/usr/bin/env python
# twistedserverpy.py -- A Twisted.Web static file server with .rpy file support

from twisted.web import server, static, script
from twisted.internet import reactor

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage: %s /path/to/serve" % (sys.argv[0],)
        sys.exit(1)
    
    root = static.File(sys.argv[1])
    root.ignoreExt(".rpy")
    root.processors = { '.rpy': script.ResourceScript }
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
