#!/usr/bin/env python
# twistedurl1.py -- A Twisted.Web with two attached resources.

from twisted.web import server, resource
from twisted.internet import reactor

class RootResource(resource.Resource):
    def getChild(self, name, request):
        if name == '':
            return self
        else:
            return resource.Resource.getChild(self, name, request)
    
    def render_GET(self, request):
        return "I am the Root resource.\r\n"

class ForumResource(resource.Resource):
    isLeaf = True
    def render_GET(self, request):
        return "I am a Forum resource. request.postpath=%r\r\n" % \
               (request.postpath,)

class ArchiveResource(resource.Resource):
    isLeaf = True
    def render_GET(self, request):
        return "I am an Archive resource. request.postpath=%r\r\n" % \
               (request.postpath,)

if __name__ == '__main__':
    root = RootResource()
    root.putChild('talkback', ForumResource())
    root.putChild('newsroom', ArchiveResource())
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
