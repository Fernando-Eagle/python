from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
_magic_number = 2
_modified_time = 1210580860.5037041
_template_filename='mako1.txt'
_template_uri='mako1.txt'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = []


def render_body(context,**pageargs):
    context.caller_stack.push_frame()
    try:
        __M_locals = dict(pageargs=pageargs)
        body = context.get('body', UNDEFINED)
        to = context.get('to', UNDEFINED)
        fromvar = context.get('fromvar', UNDEFINED)
        subject = context.get('subject', UNDEFINED)
        # SOURCE LINE 1
        context.write(u'From: ')
        context.write(unicode(fromvar))
        context.write(u'\nTo: ')
        # SOURCE LINE 2
        context.write(unicode(to))
        context.write(u'\nSubject: ')
        # SOURCE LINE 3
        context.write(unicode(subject))
        context.write(u'\n\n')
        # SOURCE LINE 5
        context.write(unicode(body))
        context.write(u'\n')
        return ''
    finally:
        context.caller_stack.pop_frame()


