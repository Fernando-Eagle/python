#!/usr/bin/env python
# simplehttpserver.py -- a simple HTTP server to expose a directory hierarchy

import BaseHTTPServer
import SimpleHTTPServer
            
def run_server(port=9090):
    server_class   = BaseHTTPServer.HTTPServer
    handler_class  = SimpleHTTPServer.SimpleHTTPRequestHandler
    server_address = ('', port)
    
    server = server_class(server_address, handler_class)
    server.serve_forever()

if __name__ == '__main__':
    run_server()
