#!/usr/bin/env python
# cgierror.py -- show stack track with cgitb

import cgitb; cgitb.enable()

print "Content-type: text/html"
print

class MyError(Exception): pass

def foo(inpt): bar(inpt+1)
def bar(data): baz(data+1)
def baz(param): raise MyError("Something's wrong in baz")

foo(42)
