#!/usr/bin/env python
# twistedwebcalc.py -- A Twisted.Web calculator resource.

from twisted.web import server, resource
from twisted.internet import reactor

class WebCalc(resource.Resource):
    isLeaf = True

    def render_GET(self, request):
        if len(request.postpath) != 3:
            return "Usage: " + '/'.join(request.prepath) + "/op/arg1/arg2\r\n"

        op, arg1, arg2 = request.postpath
        if op not in ('add', 'sub', 'mul', 'div'):
            return "Invalid operator. Use 'add', 'sub', 'mul', or 'div'\r\n"

        result = 0.0
        try:
            numarg1 = float(arg1)
            numarg2 = float(arg2)
            if op == 'add': result = numarg1 + numarg2
            elif op == 'sub': result = numarg1 - numarg2
            elif op == 'mul': result = numarg1 * numarg2
            elif op == 'div':
                if numarg2 == 0: result = 'NaN'
                else:            result = numarg1 / numarg2
        except ValueError:
            result = "Invalid operand: use numerical values only\r\n"
        finally:
            return str(result) + "\r\n"

if __name__ == '__main__':
    root = WebCalc()
    
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
