#!/usr/bin/env python
# cryptutils_demo.py -- demo of cryptutils functions

from cryptutils import HMAC, Encrypt, Decrypt, pad, unpad
from base64 import b64encode, b64decode

senddata, key = "hello", "0123456789abcdef"
padded_data, pad_size = pad(senddata, 16, 'X')

# Encrypt padded_data:
cyphertext = Encrypt(padded_data, key)
signature  = HMAC(padded_data, key)            # 64 bytes!
sendmsg    = b64encode(cyphertext + signature)

# Decrypt message:
recvmsg    = b64decode(sendmsg)
cyphertext = recvmsg[:-64]
signature  = recvmsg[len(recvmsg)-64:]
plaintext  = Decrypt(cyphertext, key)
if HMAC(plaintext, key) != signature:
    raise Exception("HMAC mismatch!")

recvdata = unpad(plaintext, pad_size)

if recvdata != senddata:
    raise Exception("Decrypt o Encrypt != id")
print "Received: [%s]" % (recvdata,)
