#!/usr/bin/env python
# twistedtarpit.py -- Send a reply after a long delay.
# From: http://twistedmatrix.com/projects/web/documentation/howto/\
#       using-twistedweb.html

from twisted.web.resource import Resource
from twisted.web import server
from twisted.python.util import println
from twisted.internet import reactor

class Tarpit(Resource):
    
    isLeaf = True
    
    def __init__(self, delay):
        Resource.__init__(self)
        self.delay = delay
    
    def render_GET(self, request):
        request.write("Hello World\r\n")
        
        d = request.notifyFinish()
        d.addCallback(lambda _: println("finished normally"))
        d.addErrback(println, "error")
        reactor.callLater(self.delay, request.finish)
        
        return server.NOT_DONE_YET

resource = Tarpit(10)

if __name__ == '__main__':
    root = Tarpit(10)
    site = server.Site(root)
    reactor.listenTCP(9090, site)
    reactor.run()
