#!/usr/bin/env python
# helloooworld.py -- Hello, OO-World!

class Hello(object):
    "Hello, OO-world!"

    def __init__(self, welcome):
        "Squirrel the welcome message away"
        self.welcome = welcome
        
    def hello(self):
        "Print the saved welcome message"
        print self.welcome

def main():
    "Play around with Hello"

    # Instantiate two Hello objects:
    hel1 = Hello("Hello, World!")
    hel2 = Hello("Good Bye, Cruel World!")

    # Call hel1 and hel2's hello method:
    hel1.hello()
    hel2.hello()

if __name__ == '__main__':
    main()
