#!/usr/bin/env python
# dictdefault.py -- dictionary with default value

class dictdefault(dict):
    '''Dictionary with default value.'''
    
    __doc__ == 'A dictionary with default value'
    
    def __init__(self, default=None, mapping={}, *seq, **kwargs):
        self.default = default
        
        for key, value in mapping.items():
            self.__setitem__(key, value)
        for key, value in seq:
            self.__setitem__(key, value)
        for key, value in kwargs.items():
            self.__setitem__(key, value)
    
    def __contains__(self, key):
        return True  # Every imaginable keys is there with default value!
    
    def __getitem__(self, key):
        try:
            return super(dictdefault, self).__getitem__(key)
        except KeyError:
            return self.default
