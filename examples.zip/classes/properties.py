#!/usr/bin/env python
# properties.py -- how to define properties.

class MyClass(object):
    def __init__(self, initval=0):
        print "Object created at 0x%x" % id(self)
        self._x = initval
        
    def getter(self):
        print "getter(0x%x) called" % id(self)
        return self._x

    def setter(self, value):
        print "setter(0x%x, %d) called" % (id(self), value)
        self._x = value

    def deleter(self):
        print "deleter(0x%x) called" % id(self)
        del self._x

    x = property(getter, setter, deleter, "I'm a managed attribute")
