#!/usr/bin/env python
# dictci.py -- dictionary with case-insensitive (string) keys.

class dictci(dict):
    '''Dictionary with case-insensitive (string) keys.'''
    
    __doc__ == 'A case insensitive dictionary'
    
    def __init__(self, mapping={}, *seq, **kwargs):
        for key, value in mapping.items():
            self.__setitem__(key.lower(), value)
        for key, value in seq:
            self.__setitem__(key.lower(), value)
        for key, value in kwargs.items():
            self.__setitem__(key.lower(), value)
    
    def __contains__(self, key):
        return super(dictci, self).__contains__(key.lower())
    
    def __delitem__(self, key):
        return super(dictci, self).__delitem__(key.lower())
    
    def __getitem__(self, key):
        return super(dictci, self).__getitem__(key.lower())
    
    def __setitem__(self, key, value):
        return super(dictci, self).__setitem__(key.lower(), value)
