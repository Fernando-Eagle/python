#!/usr/bin/env python
# posint.py -- positive integers implemented as a property

class PosInt(object):
    "A positive integer"
    
    class InvalidValue(Exception):
        pass
    
    def __init__(self, i):
        if i <= 0:
            raise PosInt.InvalidValue("Only positive integers allowed")
        self._i = i
    
    def getter(self):
        return self._i
    
    def setter(self, value):
        if value <= 0:
            raise PosInt.InvalidValue("Only positive integers allowed")
        self._i = value
    
    def deleter(self):
        del self._i
    
    x = property(getter, setter, deleter, "A positive integer property")
