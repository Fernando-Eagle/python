#!/usr/bin/env python
# chattydescriptor.py -- A verbose descriptor class.

class ChattyDescriptor(object):
    "A chatty descriptor class"
    def __init__(self):
        self.store = {}

    def __get__(self, instance, owner):
        print "CALLED __get__(%s, %s, %s)" % \
              (str(self), str(instance), str(owner))
        try:
            value = self.store[instance]
            self.store[instance] = value + 1
            return value
        except KeyError:
            raise AttributeError("There is no such attribute")
    
    def __set__(self, instance, value):
        print "CALLED __set__(%s, %s, %s)" % \
              (str(self), str(instance), str(value))
        self.store[instance] = value
    
    def __delete__(self, instance):
        print "CALLED __delete__(%s, %s)" % \
              (str(self), str(instance))
        del self.store[instance]
    
    def keyhole(self):
        return self.store
