#!/usr/bin/env python
# classdef.py -- Defining classes

class ObjectCounter(object):
    "A class that counts how many objects it created."
    
    nr_objects = 0
    
    def __init__(self, value=''):
        "Create a new object. Count it!"
        ObjectCounter.nr_objects = ObjectCounter.nr_objects + 1
        self.value = value
    
    def get_value(self):
        "Get the value of this object"
        return self.value
    
    def set_value(self, newvalue):
        "Change the value of this object"
        self.value = newvalue
    
    def object_count(self):
        "Return the number of ObjectCounter objects created so far."
        return ObjectCounter.nr_objects
    
    # This is a class method
    def override_object_count_cmethod(cls, newcount):
        print "Overriding %s.%d with %d" % (cls, cls.nr_objects, newcount)
        cls.nr_objects = newcount
    override_object_count_cmethod = classmethod(override_object_count_cmethod)
    
    # This is a static method
    def override_object_count_static(newcount):
        print "Overriding object count %d with %d" % (ObjectCounter.nr_objects,
                                                      newcount)
        ObjectCounter.nr_objects = newcount
    override_object_count_static = staticmethod(override_object_count_static)
