#!/usr/bin/env python
# objecthooks.py -- instrument the class object by intercepting some hooks.

class object_i(object):
    '''An object with instrumented hooks.'''

    # __doc__ is a documentation string for the whole class
    __doc__ == 'An instrumented object'

    # __new__ is a class method for creating new instances
    def __new__(cls, *args, **kwargs):
        print "CALLED object_i.__new__(%s, %s, %s)" \
              % (cls, str(args), str(kwargs))
        return object.__new__(cls, args, kwargs)

    # The initializer (constructor)
    def __init__(self):
        print "CALLED object_i.__init__()"
        return super(object_i, self).__init__()

    # Called for del self.attrname
    def __delattr__(self, attrname):
        print "CALLED object_i.__delattr__(%s)" % (attrname,)
        return super(object_i, self).__delattr__(attrname) 

    # Called for self.attrname
    def __getattribute__(self, attrname):
        print "CALLED object_i.__getattribute__(%s)" % (attrname,)
        return super(object_i, self).__getattribute__(attrname)

    # Called for self.attrname = attrvalue
    def __setattr__(self, attrname, attrvalue):
        print "CALLED object_i.__setattr__(%s, %s)" % (attrname, attrvalue)
        return super(object_i, self).__setattr__(attrname, attrvalue)

    # Called for str(self)
    def __str__(self):
        print "CALLED object_i.__str__()"
        return 'object_i(0x%x)' % (id(self),)

    # Called for repr(self)
    def __repr__(self):
        print "CALLED object_i.__repr__()"
        return '<repr: object_i at 0x%x>' % (id(self),)

    # Called for hash(self)
    def __hash__(self):
        print "CALLED object_i.__hash__()"
        return super(object_i, self).__hash__()
