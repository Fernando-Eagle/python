#!/usr/bin/env python
# wordcount.py -- calculate word counts for all words in a file

def count_words(wordlist):
    '''count_words(wordlist) -> { 'word1': count1, 'word2': count2, ...}

    Count the number of times a word occurs in the word list wordlist.
    Return a dictionary mapping each word to its count.'''

    wordcount = {}
    for word in wordlist:
        wordcount[word] = wordcount.get(word, 0) + 1
    return wordcount

def display_wordcount_by_words(wordcount):
    "Display the word count, sorted by words."

    sorted_by_words = wordcount.keys()
    sorted_by_words.sort()

    outlist = []
    for key in sorted_by_words:
        outlist.append("(%s, %d)" % (key, wordcount[key]))
    print ' '.join(outlist)

def display_wordcount_by_counts(wordcount):
    "Display the word count, sorted by counts."

    # 0. Define a custom comparison function
    def cmp_1st(t1, t2):
        "Compare two tuples, according to their first component"
        return cmp(t1[0], t2[0])

    # 1. sort by words, ascending
    items = wordcount.items()
    items.sort(cmp=cmp_1st)

    # 2. sort by counts, descending (note: sort is stable!)
    backitems = [ (count, word) for word, count in items ]
    backitems.sort(cmp=cmp_1st, reverse=True)

    outlist = []
    for count, word in backitems:
        outlist.append("(%s, %d)" % (word, count))
    print ' '.join(outlist)

def create_word_list(input):
    "Create a list of words read from input string."

    return input.split()

def slurp_data_from_file(filename):
    "Read a text file from filename, return as string."

    # The same as: return open(filename, 'r').read()
    filein = open(filename, 'r')
    file_as_string = filein.read()
    filein.close()

    return file_as_string

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print "Usage:", sys.argv[0], "file"
        sys.exit(1)
    filename = sys.argv[1]

    theInputData = slurp_data_from_file(filename)
    theWordList  = create_word_list(theInputData)
    theWordCount = count_words(theWordList)

    print "By words:",
    display_wordcount_by_words(theWordCount)
    print "By count:",
    display_wordcount_by_counts(theWordCount)
