#!/usr/bin/env python
# chunkwise-copy.py -- copy a file chunkwise

from __future__ import with_statement

CHUNKSIZE = 4096

def chunkwise_copy(source, destination):
    "Copy file source into destination, using CHUNKSIZE sized chunks"
    with open(source, 'rb') as f_src:
        with open(destination, 'wb') as f_dest:
            buff = f_src.read(CHUNKSIZE)
            while len(buff) > 0:
                f_dest.write(buff)
                buff = f_src.read(CHUNKSIZE)

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "source destination"
        sys.exit(1)
    source, destination = sys.argv[1], sys.argv[2]
    chunkwise_copy(source, destination)
