#!/usr/bin/env python
# revwordlist2.py -- sort a list of words according to their endings.

# This uses Jon Bentley's "Programming Pearls" trick:
# $ rev < word.list | sort | rev > words.rev

from __future__ import with_statement

WORDS_LIST = '/usr/share/dict/words'
WORDS_REV  = '/tmp/words.rev'

def sort_by_endings(wordlist_in=WORDS_LIST, wordlist_out=WORDS_REV):
    "Sort wordlist_in according to words endings into wordlist_out"
    with open(wordlist_in, 'r') as f_in:
        thelist = []
        for word in f_in:
            thelist.append(word[::-1])
    
    thelist.sort()
    
    with open(wordlist_out, 'w') as f_out:
        for word in thelist:
            f_out.write(word[::-1])

if __name__ == '__main__':
    sort_by_endings()
