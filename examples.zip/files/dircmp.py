#!/usr/bin/env python
# dircmp.py -- compare two directories

import os
import sys

BLOCKSIZE = 2048   # Chunk size used in compare_two_files.

def compare_and_synchronize(srcdir, dstdir,
                            do_compare=True, verbose_compare=False):
    '''Synchronize srcdir and dstdir so that dstdir becomes like srcdir.

    This function returns a (Unix) shell script as a string,
    that would, if run, synchronize directory dstdir with srcdir.
    
    The logic is:
      1. Files in srcdir that are not yet in dstdir will be copied over.
      2. Files in dstdir that are no longer in srcdir will be removed
         from dstdir.
      3. Files in srcdir and dstdir that are both present but different,
         will be copied from srcdir to dstdir, so as to overwrite the
         ones in dstdir that were different.
    
    In other words: srcdir will never be touched, but dstdir may be.
    
    If do_compare is False, files in the compare list will NOT
    be compared. If verbose_compare is True, the pathnames of
    files that are being compared will be listed on sys.stderr.
    
    IMPORTANT: New directories WILL NOT be created under dstdir.
    This can and will cause the synchronization to fail! You will
    need to extend this function accordingly.
    
    compare_and_synchronize will return a string that could be
    run as a shell script. It does NOT run the script itself!'''
    
    result = []
    result.append('#!/bin/sh')
    result.append('# synchronize %s and %s' % (srcdir, dstdir))
    result.append('')
    
    addlist, dellist, cmplist = compare_dirs(srcdir, dstdir)

    result.append('# copy new files from srcdir to dstdir')
    for fname in addlist:
        result.append('cp %s %s' % (os.path.join(srcdir, fname),
                                    os.path.join(dstdir, fname)))
    result.append('')
    
    result.append('# delete old files from dstdir')
    for fname in dellist:
        result.append('rm %s' % os.path.join(dstdir, fname))
    result.append('')
    
    result.append('# copy modified files from srcdir to dstdir')
    if do_compare:
        result.extend(compare_all_files(srcdir, dstdir, cmplist,
                                        verbose=verbose_compare))
    else:
        result.append('# NOTE: skipped file-by-file comparison with -n')
    
    print '\n'.join(result)

def compare_dirs(srcdir, dstdir):
    '''Compare two directories srcdir and dstdir.
    
    This function recurses through srcdir and dstdir, and tries
    to establish the steps needed to synchronize both directories
    so that dstdir becomes like srcdir. srcdir is assumed to be
    the required reference, and dstdir is to be changed accordingly.
    
    compare_dirs returns a tuple of three lists:
      1. A list of files from srcdir that needs to be added to dstdir
      2. A list of files from dstdir that needs to be removed.
      3. A list of files from srcdir to compare to those in dstdir.
    
    All lists contain pathnames that are relative to
    srcdir and dstdir respectively (i.e. they start with './').'''
    
    lsrc = traverse_dir(srcdir)
    ldst = traverse_dir(dstdir)
    lsrc.sort()
    ldst.sort()
    addme, delme, cmpme = compare_lists(lsrc, ldst)
    return addme, delme, cmpme
    
def traverse_dir(dir):
    '''Traverse dir and return a list of file names relative to dir.
    
    This function traverses directory dir, and builds up a list of
    path names for all FILES in and below dir. All path names are
    relative to dir (i.e. they start with './').
    
    traverse_dir returns that list of strings as a list.'''
    
    result = []
    
    olddir = os.getcwd()
    os.chdir(dir)
    
    for root, dirs, files in os.walk('.', topdown=True):
        for fname in files:
            result.append(os.path.join(root, fname))
    
    os.chdir(olddir)
    
    return result

def compare_lists(lst_src, lst_dst):
    '''Compute the add, del, and cmp lists.
    
    This function compares two lists of file pathnames (both
    relative to '.') and builds three lists along the way:
      1. addlist for all files in lst_src that are not yet in lst_dst
      2. dellist for all files in lst_dst that are no longer in lst_src
      3. cmplist for all files that are both in lst_src and lst_dst.
    
    compare_lists returns addlist, dellist, cmplist as a tuple.'''
    
    addlist, dellist, cmplist = [], [], []
    set_src, set_dst = set(lst_src), set(lst_dst)
    
    for path in lst_src:
        if path not in set_dst:
            addlist.append(path)
        else:
            cmplist.append(path)

    for path in lst_dst:
        if path not in set_src:
            dellist.append(path)

    return addlist, dellist, cmplist

def compare_all_files(srcdir, dstdir, cmplist, verbose=False):
    '''Compare all files in cmplist, relative to srcdir and dstdir.
    
    This function compares all files in cmplist, by reading them
    from srcdir and dstdir respectively. Along the way, a list
    of shell commands (actually 'cp' commands) is built, that
    would, if run, synchronize all files common to both srcdir and
    dstdir. Files that are different will be copied from srcdir to
    dstdir.

    The verbose parameter will be passed to compare_two_files.
    
    compare_all_files returns the list of shell commands AS LIST.'''
    
    result = []
    
    for fname in cmplist:
        srcpath = os.path.join(srcdir, fname)
        dstpath = os.path.join(dstdir, fname)
        res = compare_two_files(srcpath, dstpath, verbose=verbose)
        if res is not True:
            result.append('cp %s %s' % (srcpath, dstpath))
    
    return result

def compare_two_files(path1, path2, blocksize=BLOCKSIZE, verbose=False):
    '''Compare two files path1 and path2, blocksize bytes at a time.

    This function reads path1 and path2 chunk-wise by fetching
    blocksize bytes at a time from both files. The chunks are
    compared and discared immediately, so that even big files
    are compared efficiently.

    If any input/output error occurs, the files are assumed to
    be different.
    
    If verbose is True, path1 will be displayed on sys.stderr.
    
    compare_two_files returns True or False according to the
    outcome of the comparison.'''
    
    if verbose:
        print >>sys.stderr, "Checking", path1
    
    try:
        f1 = open(path1, 'rb')
        f2 = open(path2, 'rb')
        
        chunk1 = f1.read(BLOCKSIZE)
        chunk2 = f2.read(BLOCKSIZE)
        while len(chunk1) > 0:
            if chunk1 != chunk2:
                # both files can't be equal if two chunks differ.
                f1.close()
                f2.close()
                return False
            # read next chunks
            chunk1 = f1.read(BLOCKSIZE)
            chunk2 = f2.read(BLOCKSIZE)
        
        # If the last read chunk from f2 was not empty
        # f2 is longer than f1
        if len(chunk2) != 0:
            return False
        
        f1.close()
        f2.close()
        return True
    except IOError:
        return False

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print "Usage:", sys.argv[0], "[-n|-v] srcdir dstdir"
        sys.exit(1)

    really_compare_files    = True
    verbosely_compare_files = False
    
    if sys.argv[1] == '-n':
        really_compare_files = False
        del sys.argv[1]
    elif sys.argv[1] == '-v':
        verbosely_compare_files = True
        del sys.argv[1]
        
    srcdir, dstdir = sys.argv[1], sys.argv[2]
    compare_and_synchronize(srcdir, dstdir,
                            do_compare=really_compare_files,
                            verbose_compare=verbosely_compare_files)
