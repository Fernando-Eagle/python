#!/usr/bin/env python
# fingerprint.py -- fingerprints files with MD5 and SHA1

import hashlib

def compute_md5(file):
    digester = hashlib.md5()
    return _compute_digest(file, digester)

def compute_sha1(file):
    digester = hashlib.sha1()
    return _compute_digest(file, digester)

_BLOCKSIZE = 2048
def _compute_digest(file, digest_algorithm):
    while 1:
        chunk = file.read(_BLOCKSIZE)
        if not chunk: break
        digest_algorithm.update(chunk)
    file.close()
    return digest_algorithm.hexdigest()

if __name__ == '__main__':
    import sys, getopt
    try:
        opts, args = getopt.getopt(sys.argv[1:], "ms", [ "md5", "sha1" ])
    except getopt.GetoptError:
        print "Usage: %s [-m | -s] [path ...]" % sys.argv[0]
        sys.exit(0)

    m, s = None, None
    for o, a in opts:
        if o in ("-m", "--md5"): m = True
        if o in ("-s", "--sha1"): s = True
    if m is None and s is None: m = True;       # Default is MD5

    for pname in args:
        if m == True:
            print "MD5 (%s) = %s" % (pname, compute_md5(open(pname, "rb")))
        if s == True:
            print "SHA1 (%s) = %s" % (pname, compute_sha1(open(pname, "rb")))

