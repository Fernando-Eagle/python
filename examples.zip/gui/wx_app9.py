#!/usr/bin/env python
# wx_app9.py -- Multiple Python Threads and one GUI

from counterthread import CounterThread
import wx
import wx.lib.newevent

# This creates a new Event class and a EVT binder function
(UpdateTextEvent, EVT_UPDATE_TEXT) = wx.lib.newevent.NewEvent()

class CounterGUI(wx.Frame):
    def __init__(self, numThreads=5, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)

        self.fields  = []       # a list of wx.TextCtrl fields for the threads
        self.buttons = []       # a list of (startButton, stopButton) objects
        self.numThreads = numThreads         # number of worker threads
        self.threads = self.createThreads()  # a list of worker threads
        
        self.BuildGUI()
        self.Bind(EVT_UPDATE_TEXT, self.OnUpdate)

    def createThreads(self):
        threads = []
        for i in range(self.numThreads):
            thr = CounterThread(self.callbackFn, 3+i)
            thr.setName("<Thread %d>" % (i,))
            threads.append(thr)
        return threads
        
    def BuildGUI(self):
        self.panel = wx.Panel(self, wx.ID_ANY)
        self.sizer = wx.GridSizer(self.numThreads, 4, 2, 10) # rows, cols,
                                                             # vgap, hgab
        
        for i in range(self.numThreads):
            textfield = wx.TextCtrl(self.panel, id=wx.ID_ANY)
            textfield.Enable(False)  # read only text field
            self.fields.append(textfield)

            buttonStart = wx.Button(self.panel, label="Start Thread")
            self.Bind(wx.EVT_BUTTON, handler=self.startThread,
                      source=buttonStart)

            buttonStop  = wx.Button(self.panel, label="Stop Thread")
            self.Bind(wx.EVT_BUTTON, handler=self.stopThread,
                      source=buttonStop)
            buttonStop.Enable(False)

            self.buttons.append((buttonStart, buttonStop))

            self.sizer.Add(wx.StaticText(self.panel, label="Thread %d" % (i,)))
            self.sizer.Add(textfield, wx.EXPAND)
            self.sizer.Add(buttonStart)
            self.sizer.Add(buttonStop)

        self.panel.SetSizer(self.sizer)
        self.sizer.Fit(self)

    def callbackFn(self, theThread, theCounter):
        "Called to update the GUI. Runs in calling worker thread."
        threadID = self.threads.index(theThread)
        evt = UpdateTextEvent(threadNum=threadID, value=theCounter)
        wx.PostEvent(self, evt)

    def OnUpdate(self, evt):
        "Updates the GUI. Runs in the main GUI thread."
        threadID     = evt.threadNum
        counterValue = evt.value
        self.fields[threadID].SetValue(str(counterValue))
    
    def startThread(self, evt):
        startButton = evt.GetEventObject()
        buttonID = [lst[0] for lst in self.buttons].index(startButton)
        thread = self.threads[buttonID]
        
        startButton.Enable(False)               # can't start thread anew
        self.buttons[buttonID][1].Enable(True)  # enable stop button
        thread.start()

    def stopThread(self, evt):
        stopButton = evt.GetEventObject()
        buttonID = [lst[1] for lst in self.buttons].index(stopButton)
        thread = self.threads[buttonID]
        
        stopButton.Enable(False)
        thread.stop()                           # may take some seconds
                                                # to be picked up by thread
        
if __name__ == '__main__':
    import sys
    number_of_threads = int(sys.argv[1])
    
    app = wx.App()
    frame = CounterGUI(parent=None, title='Threads controlling a GUI',
                       numThreads=number_of_threads)
    frame.Show(True)
    app.MainLoop()
