#!/usr/bin/env python
# pyqt4_pyuic_load_ui2.py -- Load demo.ui and merge it into a `QDialog` class
# From: /usr/local/share/examples/py-qt4/pyuic/load_ui2.py

import sys
from PyQt4 import QtCore, QtGui, uic

class DemoImpl(QtGui.QDialog):
    def __init__(self, *args):
        QtGui.QWidget.__init__(self, *args)
        uic.loadUi("demo.ui", self)

    @QtCore.pyqtSignature("")
    def on_button1_clicked(self):
        for s in "This is a demo".split(" "):
            self.list.addItem(s)

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    widget = DemoImpl()
    widget.show()
    app.exec_()