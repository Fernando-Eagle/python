#!/usr/bin/env python
# wx_app7.py -- simulating a non-responsive GUI

import time
import wx

class NonResponsiveGUI(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)
        
        self.sb = wx.StatusBar(self)
        self.sb.SetStatusText("Ready")
        self.SetStatusBar(self.sb)
        
        self.button = wx.Button(self, id=100, label="Start slow_op")
        self.Bind(event=wx.EVT_BUTTON, handler=self.handler, id=100)
        
        self.count = 0L
        
    def handler(self, evt):
        "Simulate a slow operation"
        time.sleep(10)

        self.count = self.count + 1L
        self.sb.SetStatusText(str(self.count))

if __name__ == '__main__':
    app = wx.App()
    frame = NonResponsiveGUI(None, title='Freezing GUI',
                             size=(400, 100))
    frame.Show(True)
    app.MainLoop()
