#!/usr/bin/env python
# wx_app7a.py -- simulating a responsive GUI with wx.CallLater

import wx
from wx_app7 import NonResponsiveGUI

class CallLaterGUI(NonResponsiveGUI):
    def __init__(self, protect=True, *args, **kw):
        NonResponsiveGUI.__init__(self, *args, **kw)
        self.protect = protect
        
    def handler(self, evt):
        "Simulate a slow operation"
        if self.protect:
            self.button.Enable(False)
        self.timer = wx.CallLater(10000, self.OnTimer)

    def OnTimer(self):
        self.count = self.count + 1L
        self.sb.SetStatusText(str(self.count))
        if self.protect:
            self.button.Enable(True)

if __name__ == '__main__':
    import sys
    protectValue = (sys.argv[1] == 'True')
    
    app = wx.App()
    frame = CallLaterGUI(protect=protectValue,
                         parent=None, title='CallLater GUI', size=(400, 100))
    frame.Show(True)
    app.MainLoop()
