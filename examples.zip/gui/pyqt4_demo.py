# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'demo.ui'
#
# Created: Mon Jun 09 04:45:23 2008
#      by: PyQt4 UI code generator 4.3.4-snapshot-20080328
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_DemoDialog(object):
    def setupUi(self, DemoDialog):
        DemoDialog.setObjectName("DemoDialog")
        DemoDialog.resize(QtCore.QSize(QtCore.QRect(0,0,400,300).size())
		                      .expandedTo(DemoDialog.minimumSizeHint()))

        self.gridlayout = QtGui.QGridLayout(DemoDialog)
        self.gridlayout.setMargin(9)
        self.gridlayout.setSpacing(6)
        self.gridlayout.setObjectName("gridlayout")

        spacerItem = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,
		                               QtGui.QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem,2,0,1,1)

        spacerItem1 = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,
		                                QtGui.QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem1,0,0,1,1)

        self.list = QtGui.QListWidget(DemoDialog)
        self.list.setObjectName("list")
        self.gridlayout.addWidget(self.list,0,1,3,1)

        self.vboxlayout = QtGui.QVBoxLayout()
        self.vboxlayout.setMargin(0)
        self.vboxlayout.setSpacing(6)
        self.vboxlayout.setObjectName("vboxlayout")

        self.button1 = QtGui.QPushButton(DemoDialog)
        self.button1.setObjectName("button1")
        self.vboxlayout.addWidget(self.button1)

        self.button2 = QtGui.QPushButton(DemoDialog)
        self.button2.setObjectName("button2")
        self.vboxlayout.addWidget(self.button2)
        self.gridlayout.addLayout(self.vboxlayout,1,0,1,1)

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setMargin(0)
        self.hboxlayout.setSpacing(6)
        self.hboxlayout.setObjectName("hboxlayout")

        spacerItem2 = QtGui.QSpacerItem(131,31,QtGui.QSizePolicy.Expanding,
		                                QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem2)

        self.okButton = QtGui.QPushButton(DemoDialog)
        self.okButton.setObjectName("okButton")
        self.hboxlayout.addWidget(self.okButton)
        self.gridlayout.addLayout(self.hboxlayout,3,0,1,2)

        self.retranslateUi(DemoDialog)
        QtCore.QObject.connect(self.okButton,QtCore.SIGNAL("clicked()"),
		                       DemoDialog.accept)
        QtCore.QObject.connect(self.button2,QtCore.SIGNAL("clicked()"),
		                       self.list.clear)
        QtCore.QMetaObject.connectSlotsByName(DemoDialog)

    def retranslateUi(self, DemoDialog):
        DemoDialog.setWindowTitle(QtGui.QApplication.translate("DemoDialog",
		        "PyUIC4 Demo Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("DemoDialog",
		        "Add items", None, QtGui.QApplication.UnicodeUTF8))
        self.button2.setText(QtGui.QApplication.translate("DemoDialog",
		        "Clear list", None, QtGui.QApplication.UnicodeUTF8))
        self.okButton.setText(QtGui.QApplication.translate("DemoDialog",
		        "OK", None, QtGui.QApplication.UnicodeUTF8))