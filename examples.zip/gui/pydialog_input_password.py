#!/usr/bin/env python
# pydialog_input_password.py -- inputbox, passwordbox, msgbox

import dialog

def verify_credentials(d):
    "Get username / password, and verify credentials"
    (code, username) = d.inputbox("What is your name?")
    (code, password) = d.passwordbox("What is your password?")

    if username == "Falken" and password == "CPE 1704 TKS":
        d.msgbox("You authenticated successfully.")
        return True
    else:
        d.msgbox("Sorry. Authorized personnel only.")
        return False

if __name__ == '__main__':
    d = dialog.Dialog(dialog="cdialog")
    result = verify_credentials(d)
    print "Credentials:", result
