#!/usr/bin/env python
# wx_app5.py -- Querying a password with a TextEntryDialog window

import wx

class QueryFrame(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)

        button = wx.Button(self, wx.ID_ANY, label="Click me")
        button.Bind(event=wx.EVT_BUTTON, handler=self.OnClick)

    def OnClick(self, evt):
        dialog = wx.TextEntryDialog(self, message="Password, please?",
                                    caption="Password query",
                                    style=wx.OK | wx.CANCEL | wx.TE_PASSWORD)
        dialog.SetValue("Your password here...")
        result = dialog.ShowModal()

        if result == wx.ID_OK:
            passwd = dialog.GetValue()
        elif result == wx.ID_CANCEL:
            passwd = "No password supplied"
        else:
            passwd = "Eh?"

        dialog.Destroy()

        wx.MessageDialog(self, message="Your password: " + passwd,
                         caption="Query result", style=wx.OK).ShowModal()

if __name__ == '__main__':
    app = wx.App()
    qframe = QueryFrame(None, id=wx.ID_ANY,
                        title="A query frame", size=(400, 200))
    qframe.Show(True)
    app.MainLoop()
