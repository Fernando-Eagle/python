#!/usr/bin/env python
# wx_app8.py -- simulating a responsive GUI with DelayedResults and Cancel

import time
import wx
import wx.lib.delayedresult as delayedresult

class DelayedResultsCancelGUI(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)

        self.count = 0L
        self.is_running = False
        self.Bind(wx.EVT_CLOSE, self.OnClose)

        self.sb = wx.StatusBar(self)
        self.sb.SetStatusText("Ready")
        self.SetStatusBar(self.sb)

        self.panel = wx.Panel(self, wx.ID_ANY)
        self.sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.buttonStart = wx.Button(self.panel, id=100, label="Start Thread")
        self.buttonStop  = wx.Button(self.panel, id=101, label="Stop Thread")
        
        self.buttonStart.Enable(True)
        self.buttonStop.Enable(False)
        
        self.sizer.Add(self.buttonStart, wx.EXPAND)
        self.sizer.Add(self.buttonStop,  wx.EXPAND)
        
        self.Bind(event=wx.EVT_BUTTON, handler=self.handlerStart, id=100)
        self.Bind(event=wx.EVT_BUTTON, handler=self.handlerStop,  id=101)
        
        self.panel.SetSizer(self.sizer)
        self.sizer.Fit(self)

    def OnClose(self, evt):
        self.is_running = False
        self.Destroy()
        
    def handlerStart(self, evt):
        "Called when buttonStart is clicked"
        self.is_running = True
        self.buttonStart.Enable(False)
        self.buttonStop.Enable(True)
        delayedresult.startWorker(self.consumeResult, self.produceResult)

    def handlerStop(self, evt):
        "Called when buttonStop is clicked"
        self.is_running = False
        self.buttonStop.Enable(False)
    
    def produceResult(self):
        "Simulates a slow operation running in its own thread"
        time.sleep(10)
        if self.is_running:
            return self.count + 1L
        else:
            return "Aborted"
    
    def consumeResult(self, delayedResult):
        "Collects results from worker thread, running in main thread"
        result = delayedResult.get()
        if result != "Aborted":
            self.count = result
        self.sb.SetStatusText(str(result))
        self.buttonStart.Enable(True)
        self.buttonStop.Enable(False)

if __name__ == '__main__':
    app = wx.App()
    frame = DelayedResultsCancelGUI(None, title='DelayedResultsCancel GUI',
                                    size=(400, 100))
    frame.Show(True)
    app.MainLoop()
