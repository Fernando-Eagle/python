#!/usr/bin/env python
# wx_app2a.py -- A window with one button, using inheritance

import wx

class FrameWithOneButton(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)
        button = wx.Button(self, wx.ID_EXIT, label="Exit")
        button.Bind(event=wx.EVT_BUTTON, handler=lambda evt: self.Close())

if __name__ == '__main__':
    app = wx.App()
    bframe = FrameWithOneButton(None, id=wx.ID_ANY,
                                title="A frame with one button",
                                size=(400, 200))
    bframe.Show(True)
    app.MainLoop()
