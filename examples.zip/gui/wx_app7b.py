#!/usr/bin/env python
# wx_app7b.py -- simulating a responsive GUI with wx.Timer and wx.EVT_TIMER

import wx
from wx_app7 import NonResponsiveGUI

class EVT_TIMER_GUI(NonResponsiveGUI):
    def __init__(self, *args, **kw):
        NonResponsiveGUI.__init__(self, *args, **kw)
        self.Bind(wx.EVT_TIMER, self.OnTimer)
        
    def handler(self, evt):
        "Simulate a slow operation"
        self.button.Enable(False)
        self.timer = wx.Timer(self)
        self.timer.Start(10000)

    def OnTimer(self, evt):
        self.timer.Stop()
        self.count = self.count + 1L
        self.sb.SetStatusText(str(self.count))
        self.button.Enable(True)

if __name__ == '__main__':
    app = wx.App()
    frame = EVT_TIMER_GUI(None, title='EVT_TIMER GUI', size=(400, 100))
    frame.Show(True)
    app.MainLoop()
