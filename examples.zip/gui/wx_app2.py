#!/usr/bin/env python
# wx_app2.py -- A window with one button.

import wx

app = wx.App()

frame = wx.Frame(None, wx.ID_ANY, title="A frame", size=(400, 200))
button = wx.Button(frame, wx.ID_EXIT, label="Exit")
button.Bind(event=wx.EVT_BUTTON, handler=lambda evt: frame.Close())

frame.Show(True)
app.MainLoop()
