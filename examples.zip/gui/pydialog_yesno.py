#!/usr/bin/env python
# pydialog_yesno.py -- yes/no box

import dialog

the_question = '''You are about to nuke the planet.

Do you really, absolutely without any doubts want to do it? Do you
realize that there is no way to undo this action? Please confirm that
you intend to nuke the whole planet now!'''

d = dialog.Dialog(dialog="cdialog")
result = d.yesno(text=the_question, width=40, height=12)
print "Result:", result == d.DIALOG_OK
