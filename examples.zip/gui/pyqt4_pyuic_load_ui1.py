#!/usr/bin/env python
# pyqt4_pyuic_load_ui1.py -- dynamically load demo.py
# From: /usr/local/share/examples/py-qt4/pyuic/load_ui1.py

import sys
from PyQt4 import QtGui, uic

app = QtGui.QApplication(sys.argv)
widget = uic.loadUi("demo.ui")
widget.show()
app.exec_()