#!/usr/bin/env python
# counterthread.py -- A Thread which acts like a counter and a timer.

from threading import Thread
import time

class CounterThread(Thread):
    def __init__(self, callbackFn, pace=1):
        Thread.__init__(self)
        self.callbackFn = callbackFn
        self.pace = pace
        self.counter = 0L
        self.keepGoing = True
    
    def run(self):
        while self.keepGoing:
            time.sleep(self.pace)
            self.counter = self.counter + 1L
            self.callbackFn(self, self.counter)
    
    def stop(self):
        self.keepGoing = False
