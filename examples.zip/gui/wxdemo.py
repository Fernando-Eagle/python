#!/usr/bin/env python
# wxdemo.py -- Integrating Twisted and wxPython event loops with wxreactor
# Copyright (c) 2001-2006 Twisted Matrix Laboratories.
# Adapted from ${twisted_src}/doc/core/examples/wxdemo.py

import sys
import wx

from twisted.python import log
from twisted.internet import wxreactor
wxreactor.install()

# import twisted.internet.reactor only after installing wxreactor:
from twisted.internet import reactor, defer

class MyFrame(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, size=(300,200), *args, **kwargs)
        menu = wx.Menu()
        menu.Append(wx.ID_EXIT, "E&xit", "Terminate the program")
        menuBar = wx.MenuBar()
        menuBar.Append(menu, "&File")
        self.SetMenuBar(menuBar)
        self.Bind(wx.EVT_MENU, self.DoExit, id=wx.ID_EXIT)
		
        # make sure reactor.stop() is used to stop event loop:
        self.Bind(wx.EVT_CLOSE, lambda evt: reactor.stop())

    def DoExit(self, event):
        reactor.stop()

class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None, id=wx.ID_ANY, title="Hello, world")
        frame.Show(True)
        self.SetTopWindow(frame)
        # look, we can use twisted calls!
        reactor.callLater(10, self.tenSecondsPassed)
        return True
		
    def tenSecondsPassed(self):
        print "ten seconds passed"

def demo():
    log.startLogging(sys.stdout)

    # register the wxApp instance with Twisted:
    app = MyApp(0)
    reactor.registerWxApp(app)

    # start the event loop:
    reactor.run()

if __name__ == '__main__':
    demo()
