#!/usr/bin/env python
# wx_app4.py -- A button and a dialog window

import wx

class FrameWithButtonAndDialog(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)

        button = wx.Button(self, wx.ID_ANY, label="Click me")
        button.Bind(event=wx.EVT_BUTTON, handler=self.OnClick)

    def OnClick(self, evt):
        dialog = wx.MessageDialog(self, message="Thank you for clicking me",
                                  caption="Button clicked",
                                  style=wx.OK | wx.ICON_INFORMATION)
        dialog.ShowModal()

if __name__ == '__main__':
    app = wx.App()
    bdframe = FrameWithButtonAndDialog(None, id=wx.ID_ANY,
                                       title="A button and a dialog",
                                       size=(400, 200))
    bdframe.Show(True)
    app.MainLoop()
