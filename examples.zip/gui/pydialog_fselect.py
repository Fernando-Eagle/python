#!/usr/bin/env python
# pydialog_fselect.py -- A file selector box

import dialog

d = dialog.Dialog(dialog="cdialog")
(code, path) = d.fselect(filepath='/usr/local/lib/python2.5/site-packages/',
                         height=10, width=50)

ret = d.msgbox(text="You selected (%d, %s)" % (code, path), width=50)
