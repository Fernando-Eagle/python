#!/usr/bin/env python
# wx_app7c.py -- simulating a responsive GUI with deriving from wx.Timer

import wx
from wx_app7 import NonResponsiveGUI

class NotifyTimerGUI(NonResponsiveGUI):
    def __init__(self, *args, **kw):
        NonResponsiveGUI.__init__(self, *args, **kw)
        
    def handler(self, evt):
        "Simulate a slow operation"
        self.button.Enable(False)
        self.timer = NotifyTimer(self)
        self.timer.Start(10000)

    def OnTimer(self):
        self.timer.Stop()
        self.count = self.count + 1L
        self.sb.SetStatusText(str(self.count))
        self.button.Enable(True)

class NotifyTimer(wx.Timer):
    def __init__(self, theFrame):
        wx.Timer.__init__(self)
        self.theFrame = theFrame

    def Notify(self):
        "Will be triggered with the timer ticks"
        self.theFrame.OnTimer()

if __name__ == '__main__':
    app = wx.App()
    frame = NotifyTimerGUI(None, title='NotifyTimer GUI', size=(400, 100))
    frame.Show(True)
    app.MainLoop()
