#!/usr/bin/env python
# wx_app3.py -- A window with two buttons

import wx

class FrameWithTwoButtons(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)
        self.panel = wx.Panel(self, wx.ID_ANY)
        self.sizer = wx.BoxSizer(wx.HORIZONTAL)

        button1 = wx.Button(self.panel, wx.ID_EXIT, label="Exit 1")
        button1.Bind(event=wx.EVT_BUTTON, handler=lambda evt: self.Close())
        self.sizer.Add(button1, wx.EXPAND)

        button2 = wx.Button(self.panel, wx.ID_EXIT, label="Exit 2")
        button2.Bind(event=wx.EVT_BUTTON, handler=lambda evt: self.Close())
        self.sizer.Add(button2, wx.EXPAND)

        self.panel.SetSizer(self.sizer)
        self.sizer.Fit(self)

if __name__ == '__main__':
    app = wx.App()
    bframe = FrameWithTwoButtons(None, id=wx.ID_ANY,
                                 title="A frame with two buttons",
                                 size=(400, 200))
    bframe.Show(True)
    app.MainLoop()
