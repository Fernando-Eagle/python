#!/usr/bin/env python
# wx_app1.py -- A first wxPython application.

import wx

app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, title="A frame", size=(400, 200))
frame.Show(True)
app.MainLoop()
