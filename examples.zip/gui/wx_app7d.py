#!/usr/bin/env python
# wx_app7d.py -- simulating a responsive GUI with DelayedResults

import time
import wx
import wx.lib.delayedresult as delayedresult
from wx_app7 import NonResponsiveGUI

class DelayedResultsGUI(NonResponsiveGUI):
    def __init__(self, protect=True, *args, **kw):
        NonResponsiveGUI.__init__(self, *args, **kw)
        self.protect = protect
        
    def handler(self, evt):
        "Called when self.button is clicked"
        if self.protect:
            self.button.Enable(False)
        delayedresult.startWorker(self.consumeResult, self.produceResult)
    
    def produceResult(self):
        "Simulates a slow operation running in its own thread"
        time.sleep(10)
        return self.count + 1L
    
    def consumeResult(self, delayedResult):
        "Collects results from worker thread, running in main thread"
        self.count = delayedResult.get()
        self.sb.SetStatusText(str(self.count))
        if self.protect:
            self.button.Enable(True)

if __name__ == '__main__':
    import sys
    protectValue = (sys.argv[1] == 'True')
    
    app = wx.App()
    frame = DelayedResultsGUI(protect=protectValue,
                              parent=None, title='DelayedResults GUI',
                              size=(400, 100))
    frame.Show(True)
    app.MainLoop()
