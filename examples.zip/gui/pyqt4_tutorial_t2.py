#!/usr/bin/env python
# pyqt4_tutorial_t2.py -- PyQt tutorial 2
# From: /usr/local/share/examples/py-qt4/tutorial/t2.py

import sys
from PyQt4 import QtCore, QtGui

app = QtGui.QApplication(sys.argv)

quit = QtGui.QPushButton("Quit")
quit.resize(75, 30)
quit.setFont(QtGui.QFont("Times", 18, QtGui.QFont.Bold))

QtCore.QObject.connect(quit, QtCore.SIGNAL("clicked()"),
                       app, QtCore.SLOT("quit()"))

quit.show()
sys.exit(app.exec_())