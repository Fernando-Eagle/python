#!/usr/bin/env python
# tksimple.py -- A simple 2 button application

import Tkinter
from Tkconstants import *

def build_gui():
    root = Tkinter.Tk()
    
    button1 = Tkinter.Button(root, text="Click Me!", command=button_pressed)
    button2 = Tkinter.Button(root, text="Exit",      command=root.destroy)
    
    button1.pack(side=RIGHT, fill=BOTH, expand=True)
    button2.pack(side=RIGHT, fill=BOTH, expand=True)
    
    return root

def button_pressed():
    print "Button pressed!"

root = build_gui()
root.mainloop()
