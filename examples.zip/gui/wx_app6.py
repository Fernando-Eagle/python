#!/usr/bin/env python
# wx_app6.py -- A Frame, Menu and StatusBar

import wx

class MenuAndStatusBarFrame(wx.Frame):
    def __init__(self, *args, **kw):
        wx.Frame.__init__(self, *args, **kw)

        self.createStatusBar()
        self.createMenuBar()
        self.bindMenuEvents()

    def createStatusBar(self):
        self.sb = wx.StatusBar(self, id=wx.ID_ANY)
        self.sb.SetStatusText('Ready')
        self.SetStatusBar(self.sb)

    def createMenuBar(self):
        filemenu = wx.Menu()
        filemenu.Append(id=wx.ID_NEW, text='&New', help='Create new file')
        filemenu.Append(id=wx.ID_OPEN, text='&Open', help='Open existing file')
        filemenu.Append(id=wx.ID_SAVE, text='&Save', help='Save file')
        filemenu.Append(id=wx.ID_SAVEAS, text='Save &As', help='Save file as')
        filemenu.AppendSeparator()
        filemenu.Append(id=wx.ID_EXIT, text='&Quit', help='Good bye')

        editmenu = wx.Menu()
        editmenu.Append(id=wx.ID_COPY, text='&Copy', help='Copy selected area')
        editmenu.Append(id=wx.ID_CUT, text='C&ut', help='Cut selected area')
        editmenu.Append(id=wx.ID_PASTE, text='&Paste', help='Paste clipboard')

        lmi = wx.Menu()
        lmi.Append(id=1001, text='&Python', help='Python', kind=wx.ITEM_CHECK)
        lmi.Append(id=1002, text='&Ruby',   help='Ruby',   kind=wx.ITEM_CHECK)
        lmi.Append(id=1003, text='P&erl',   help='Perl',   kind=wx.ITEM_CHECK)
        lmi.Append(id=1004, text='P&HP',    help='PHP',    kind=wx.ITEM_CHECK)
        lmi.Append(id=1005, text='&Java',   help='Java',   kind=wx.ITEM_CHECK)
        lmi.Append(id=1006, text='&Scheme', help='Scheme', kind=wx.ITEM_CHECK)

        lmc = wx.Menu()
        lmc.Append(id=1011, text='&C', help='C', kind=wx.ITEM_RADIO)
        lmc.Append(id=1012, text='C&++', help='C++', kind=wx.ITEM_RADIO)
        lmc.Append(id=1013, text='&Pascal', help='Pascal', kind=wx.ITEM_RADIO)
        lmc.Append(id=1014, text='&F95', help='Fortran95', kind=wx.ITEM_RADIO)

        langmenu = wx.Menu()
        langmenu.AppendMenu(100, '&Interpreted', lmi)
        langmenu.AppendMenu(101, '&Compiled', lmc)

        helpmenu = wx.Menu()
        helpmenu.Append(id=wx.ID_HELP, text='&Help', help='Show help')
        helpmenu.AppendSeparator()
        helpmenu.Append(id=wx.ID_ABOUT, text='&About', help='About this app')

        self.menuBar = wx.MenuBar()

        self.menuBar.Append(filemenu, '&File')
        self.menuBar.Append(editmenu, '&Edit')
        self.menuBar.Append(langmenu, '&Languages')
        self.menuBar.Append(helpmenu, '&Help')

        self.SetMenuBar(self.menuBar)

    def bindMenuEvents(self):
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_NEW)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_OPEN)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_SAVE)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_SAVEAS)

        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_COPY)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_CUT)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_PASTE)

        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=1000, id2=1014)

        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_HELP)
        self.Bind(wx.EVT_MENU, self.OnMenuHandler, id=wx.ID_ABOUT)

        self.Bind(wx.EVT_MENU, self.OnQuit, id=wx.ID_EXIT)

    def OnMenuHandler(self, evt):
        self.sb.SetStatusText('Unhandled menu event: %d' % (evt.GetId(),))

    def OnQuit(self, evt):
        self.Close()

if __name__ == '__main__':
    app = wx.App()
    mframe = MenuAndStatusBarFrame(None, id=wx.ID_ANY,
                                   title="A demo frame", size=(400, 200))
    mframe.Show(True)
    app.MainLoop()
