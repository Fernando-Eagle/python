#!/usr/bin/env python
# pyqt4_tutorial_t5.py -- PyQt tutorial 5
# From: /usr/local/share/examples/py-qt4/tutorial/t5.py

import sys
from PyQt4 import QtCore, QtGui

class MyWidget(QtGui.QWidget):
    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)

        quit = QtGui.QPushButton("Quit")
        quit.setFont(QtGui.QFont("Times", 18, QtGui.QFont.Bold))

        lcd = QtGui.QLCDNumber(2)

        slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        slider.setRange(0, 99)
        slider.setValue(0)

        self.connect(quit, QtCore.SIGNAL("clicked()"),
                     QtGui.qApp, QtCore.SLOT("quit()"))
        self.connect(slider, QtCore.SIGNAL("valueChanged(int)"),
                     lcd, QtCore.SLOT("display(int)"))

        layout = QtGui.QVBoxLayout()
        layout.addWidget(quit);
        layout.addWidget(lcd);
        layout.addWidget(slider);
        self.setLayout(layout);

if __name__ == '__main__':
	app = QtGui.QApplication(sys.argv)
	widget = MyWidget()
	widget.show()
	sys.exit(app.exec_())