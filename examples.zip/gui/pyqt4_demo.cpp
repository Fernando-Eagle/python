/********************************************************************************
** Form generated from reading ui file 'demo.ui'
**
** Created: Mon Jun 9 04:34:50 2008
**      by: Qt User Interface Compiler version 4.3.4
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_DEMO_H
#define UI_DEMO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

class Ui_DemoDialog
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *spacerItem;
    QSpacerItem *spacerItem1;
    QListWidget *list;
    QVBoxLayout *vboxLayout;
    QPushButton *button1;
    QPushButton *button2;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem2;
    QPushButton *okButton;

    void setupUi(QDialog *DemoDialog)
    {
    if (DemoDialog->objectName().isEmpty())
        DemoDialog->setObjectName(QString::fromUtf8("DemoDialog"));
    DemoDialog->resize(400, 300);
    gridLayout = new QGridLayout(DemoDialog);
#ifndef Q_OS_MAC
    gridLayout->setSpacing(6);
#endif
#ifndef Q_OS_MAC
    gridLayout->setMargin(9);
#endif
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    spacerItem = new QSpacerItem(20, 40, QSizePolicy::Minimum,
                                 QSizePolicy::Expanding);

    gridLayout->addItem(spacerItem, 2, 0, 1, 1);

    spacerItem1 = new QSpacerItem(20, 40, QSizePolicy::Minimum,
	                              QSizePolicy::Expanding);

    gridLayout->addItem(spacerItem1, 0, 0, 1, 1);

    list = new QListWidget(DemoDialog);
    list->setObjectName(QString::fromUtf8("list"));

    gridLayout->addWidget(list, 0, 1, 3, 1);

    vboxLayout = new QVBoxLayout();
#ifndef Q_OS_MAC
    vboxLayout->setSpacing(6);
#endif
    vboxLayout->setMargin(0);
    vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
    button1 = new QPushButton(DemoDialog);
    button1->setObjectName(QString::fromUtf8("button1"));

    vboxLayout->addWidget(button1);

    button2 = new QPushButton(DemoDialog);
    button2->setObjectName(QString::fromUtf8("button2"));

    vboxLayout->addWidget(button2);


    gridLayout->addLayout(vboxLayout, 1, 0, 1, 1);

    hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
    hboxLayout->setSpacing(6);
#endif
    hboxLayout->setMargin(0);
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    spacerItem2 = new QSpacerItem(131, 31, QSizePolicy::Expanding,
	                              QSizePolicy::Minimum);

    hboxLayout->addItem(spacerItem2);

    okButton = new QPushButton(DemoDialog);
    okButton->setObjectName(QString::fromUtf8("okButton"));

    hboxLayout->addWidget(okButton);


    gridLayout->addLayout(hboxLayout, 3, 0, 1, 2);


    retranslateUi(DemoDialog);
    QObject::connect(okButton, SIGNAL(clicked()), DemoDialog, SLOT(accept()));
    QObject::connect(button2, SIGNAL(clicked()), list, SLOT(clear()));

    QMetaObject::connectSlotsByName(DemoDialog);
    } // setupUi

    void retranslateUi(QDialog *DemoDialog)
    {
    DemoDialog->setWindowTitle(QApplication::translate("DemoDialog",
	           "PyUIC4 Demo Dialog", 0, QApplication::UnicodeUTF8));
    button1->setText(QApplication::translate("DemoDialog",
	           "Add items", 0, QApplication::UnicodeUTF8));
    button2->setText(QApplication::translate("DemoDialog",
	           "Clear list", 0, QApplication::UnicodeUTF8));
    okButton->setText(QApplication::translate("DemoDialog",
	           "OK", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(DemoDialog);
    } // retranslateUi
};

namespace Ui {
    class DemoDialog: public Ui_DemoDialog {};
} // namespace Ui

#endif // UI_DEMO_H