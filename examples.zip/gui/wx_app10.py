#!/usr/bin/env python
# wx_app10.py -- running a program in a wxPython GUI

import wx
import wx.richtext as rt

class RunProcess(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)

        self.size    = kwargs.get('size', ((1024,768)))
        self.process = None
        self.pid     = None
        
        self.createControls()
        self.bindEvents()
        self.createLayout()

    def createControls(self):
        "Create the UI controls / widgets for the GUI shell"
        
        self.normalfont = wx.Font(pointSize=10,
                                  family=wx.FONTFAMILY_TELETYPE,
                                  style=wx.FONTSTYLE_NORMAL,
                                  weight=wx.FONTWEIGHT_NORMAL)
        
        self.panel   = wx.Panel(self)
        
        self.command = wx.TextCtrl(self.panel, value='telnet localhost 80')
        self.command.SetFont(self.normalfont)
        self.runBtn  = wx.Button(self.panel,   label='Run!')
        
        self.output  = rt.RichTextCtrl(self.panel, value='',
                         style=rt.RE_MULTILINE | rt.RE_READONLY)
        self.output.SetFont(self.normalfont)
        
        self.input   = wx.TextCtrl(self.panel, value='',
                                   style=wx.TE_PROCESS_ENTER)
        self.input.SetFont(self.normalfont)
        self.closeBtn  = wx.Button(self.panel, label='Close stream')
        self.ctrlCBtn  = wx.Button(self.panel, label='Ctrl-C')
        self.kill9Btn  = wx.Button(self.panel, label='Kill -9')
        
        self.input.Enable(False)    # will be enabled in OnRunBtn
        self.closeBtn.Enable(False) # will be enabled in OnRunBtn
        self.ctrlCBtn.Enable(False) # will be enabled in OnRunBtn
        self.kill9Btn.Enable(False) # will be enabled in OnRunBtn
        self.command.SetFocus()

    def bindEvents(self):
        "Associate events to callback functions"

        self.Bind(wx.EVT_IDLE, self.OnIdle)
        self.Bind(wx.EVT_END_PROCESS, self.OnProcessEnded)
        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)
        
        self.Bind(wx.EVT_BUTTON, self.OnRunBtn, self.runBtn)
        self.Bind(wx.EVT_BUTTON, self.OnCloseStream, self.closeBtn)
        self.Bind(wx.EVT_BUTTON, self.OnCtrlC, self.ctrlCBtn)
        self.Bind(wx.EVT_BUTTON, self.OnKill9, self.kill9Btn)
        self.Bind(wx.EVT_TEXT_ENTER, self.OnSendText, self.input)

    def createLayout(self):
        "Layout the UI widgets into a nice shell" 
        
        runbox = wx.BoxSizer(wx.HORIZONTAL)
        runbox.Add(self.command, 1, wx.EXPAND | wx.ALL)
        runbox.Add(self.runBtn, 0)
        
        inpbox = wx.BoxSizer(wx.HORIZONTAL)
        inpbox.Add(self.input, 1, wx.EXPAND | wx.ALL)
        inpbox.Add(self.closeBtn, 0)
        inpbox.Add(self.ctrlCBtn, 0)
        inpbox.Add(self.kill9Btn, 0)
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(runbox, 0, wx.EXPAND | wx.ALL)
        vbox.Add(self.output, 1, wx.EXPAND | wx.ALL)
        vbox.Add(inpbox, 0, wx.EXPAND | wx.ALL)
        
        self.panel.SetSizer(vbox)
        vbox.Fit(self)
        self.SetSize(self.size)

    def OnRunBtn(self, evt):
        "The user wants to start a new process"
        
        cmdline = self.command.GetValue().strip()

        self.process = wx.Process(self)
        self.process.Redirect()
        self.pid = wx.Execute(cmdline, wx.EXEC_ASYNC, self.process)

        self.command.Enable(False)
        self.runBtn.Enable(False)
        self.input.Enable(True)
        self.closeBtn.Enable(True)
        self.ctrlCBtn.Enable(True)
        self.kill9Btn.Enable(True)
        self.output.SetValue('')
        self.input.SetFocus()

    def OnSendText(self, evt):
        "The user wants to send a line to the process"
        
        text = self.input.GetValue()
        self.input.SetValue('')

        self.output.BeginBold()
        self.output.AppendText(text + '\n')
        self.output.EndBold()

        self.process.GetOutputStream().write(text + '\n')
        self.input.SetFocus()

    def OnCloseStream(self, evt):
        "The user wants to close the stream to the process"
        
        if self.process is not None:
            self.process.CloseOutput()
            self.input.Enable(False)

    def OnCtrlC(self, evt):
        "The user clicked on Ctrl-C; send SIGINT to process"
        if self.process is not None:
            wx.Process.Kill(pid=self.pid, sig=wx.SIGINT,
                            flags=wx.KILL_NOCHILDREN)

    def OnKill9(self, evt):
        "The user clicked on Kill -9; send SIGKILL to process"
        if self.process is not None:
            wx.Process.Kill(pid=self.pid, sig=wx.SIGKILL,
                            flags=wx.KILL_NOCHILDREN)

    def OnIdle(self, evt):
        "When idling, read from the process"

        if self.process is not None:
            for stream in (self.process.GetInputStream(),
                           self.process.GetErrorStream()):
                if stream.CanRead():
                    text = stream.read()
                    self.output.AppendText(text)

    def OnCloseWindow(self, evt):
        "The window is closing; destroy the process"
        
        if self.process is not None:
            self.process.Destroy()
            self.process = None
        self.Destroy()
    
    def OnProcessEnded(self, evt):
        "The process terminated; react accordingly"

        stream = self.process.GetInputStream()
        if stream.CanRead():
            text = stream.read()
            self.output.AppendText(text)

        self.process.Destroy()
        self.process = None
        self.pid = None

        wx.MessageDialog(self, message='Process ended, pid:%s, exitcode:%s' % \
                                           (evt.GetPid(), evt.GetExitCode()),
                         caption='Process ended',
                         style=wx.OK | wx.ICON_INFORMATION).ShowModal()

        self.command.Enable(True)
        self.runBtn.Enable(True)
        self.input.Enable(False)
        self.closeBtn.Enable(False)
        self.ctrlCBtn.Enable(False)
        self.kill9Btn.Enable(False)
        self.command.SetFocus()
    
if __name__ == '__main__':
    app = wx.App()
    frame = RunProcess(parent=None, title='Run process')
    frame.Show(True)
    app.MainLoop()
