#!/usr/bin/env python
# zcomment.py -- A ZODB-persistent Comment class.

from persistent import Persistent

class Comment(Persistent):
    '''A Comment contains a simple text'''

    def __init__(self, subject='Comment Subject', text='Comment Text',
                 author='Anonymous'):
        self.subject = subject
        self.author  = author
        self.text    = text
    
    def __str__(self):
        return "Comment(subject='%s', author='%s', text='%s')" \
               % (self.subject, self.author, self.text)
    
    def __repr__(self):
        return "<Comment subject='%s'>" % self.subject
