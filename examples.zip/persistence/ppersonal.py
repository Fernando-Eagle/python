from personal import Personal
import persistent

class PPersonal(Personal, persistent.Persistent):
    '''A persistent Personal object'''
    
    def __str__(self):
        return 'PPersonal(%s, %s %s. %s)' % (self.pid, self.firstname,
                                             self.middlename, self.surname)

