#!/usr/bin/env python
# mp3tree.py -- get list of all files that end in .mp3 or .MP3

import os, os.path

def tree_mp3(path_to_root):
    "A generator that returns a list of all .mp3 and .MP3 files"
    for root, dirs, files in os.walk(path_to_root):
        files.sort()
        for fname in files:
            if fname.endswith('.mp3') or fname.endswith('.MP3'):
                yield os.path.join(path_to_root, root, fname)

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "dir"
        sys.exit(1)
    rootpath = sys.argv[1]
    print '\n'.join(tree_mp3(rootpath))
