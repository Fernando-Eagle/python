#!/usr/bin/env python
# zblog.py -- A ZODB-persistent Blog class.

from persistent import Persistent
from BTrees.OOBTree import OOBTree
import time

class Blog(Persistent):
    '''A Blog contains many articles'''

    def __init__(self, name='Blog Name', author='Blog Author',
                 descr='Blog description'):
        self.name = name
        self.author = author
        self.descr = descr
        self.articles = OOBTree()
        self.lastarticle = 0L

    def add_article(self, article):
        self.lastarticle = self.lastarticle + 1
        self.articles['%08d' % self.lastarticle] = (article, time.time())

    def __str__(self):
        result = []
        result.append("Blog(name='%s', author='%s'\n" \
                      % (self.name, self.author))
        result.append(" descr='%s'\n" % self.descr)
        for article_id in self.articles:
            thearticle, when_added = self.articles[article_id]
            result.append(" %s\n article_added=%s\n" \
                          % (str(thearticle), time.ctime(when_added)))
        result.append(")")
        return ''.join(result)
    
    def __repr__(self):
        return "<Blog name='%s'>" % self.name
