#!/usr/bin/env python
# mp3initdb_sqlite3.py -- create mp3collection schemas in SQLite3

import sqlite3

MP3META_SCHEMA = '''
CREATE TABLE mp3meta (
id TEXT PRIMARY KEY,
title TEXT,
artist TEXT,
album TEXT,
track INTEGER,
genre INTEGER,
comment TEXT,
year TEXT
);
'''

MP3PATHS_SCHEMA = '''
CREATE TABLE mp3paths (
id TEXT NOT NULL,
path TEXT NOT NULL
);
'''

MP3PATHS_INDEX_SCHEMA = '''
CREATE UNIQUE INDEX unique_index ON mp3paths ( id, path );
'''

def create_schema(path_to_db):
    "Create the SQLite3 database schema"
    conn = sqlite3.connect(path_to_db)
    curs = conn.cursor()
    curs.execute(MP3META_SCHEMA)
    curs.execute(MP3PATHS_SCHEMA)
    curs.execute(MP3PATHS_INDEX_SCHEMA)
    curs.close()
    conn.close()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "path/to/mp3collectiondb"
        sys.exit(1)
    path_to_db = sys.argv[1]
    create_schema(path_to_db)

