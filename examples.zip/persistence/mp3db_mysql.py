#!/usr/bin/env python
# mp3db_mysql.py -- update mp3collection database from mp3 meta data

import MySQLdb

from mp3scan import scan_mp3
from mp3tree import tree_mp3

def update_database(dsn, root, debug=False):
    "Update database dsn, starting from root path"
    
    # Open MySQL database and start transaction block
    conn = MySQLdb.connect(user=dsn['user'], passwd=dsn['passwd'],
                           host=dsn['host'], db=dsn['dbname'])
    curs = conn.cursor()
    
    for path in tree_mp3(root):
        # Read and compute meta data of file path
        m = scan_mp3(path)
        if debug: print "READ(%s)" % path
        if m is None: continue
        
        # Save meta data into mp3meta
        try:
            curs.execute('''INSERT INTO mp3meta VALUES
                         (%(sha1)s, %(title)s, %(artist)s, %(album)s,
                          %(track)s, %(genre)s, %(comment)s, %(year)s)''', m)
        except MySQLdb.DatabaseError, e:
            print "ERR1(%s, %s):" % (m['sha1'], path), e
        conn.commit()
        
        # Save path info of this file into mp3paths
        try:
            curs.execute("INSERT INTO mp3paths VALUES (%(sha1)s, %(path)s)", m)
        except MySQLdb.DatabaseError, e:
            print "ERR2(%s, %s):" % (m['sha1'], path), e
        conn.commit()
            
    # That's all, folks! Now let's clean up
    curs.close()
    conn.close()

if __name__ == '__main__':
    from getpass import getpass
    import sys
    
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "path_to_root"
        sys.exit(1)
    
    path_to_root = sys.argv[1]
    DSN = { 'user': 'pythonbook', 'passwd': getpass("Enter db password: "),
            'host': '127.0.0.1',  'dbname': 'pybookdb' }
    
    update_database(DSN, path_to_root, debug=True)
