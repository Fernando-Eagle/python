#!/usr/bin/env python
# zarticle.py -- A ZODB-persistent Article class.

from persistent import Persistent
from BTrees.OOBTree import OOBTree
import time

class Article(Persistent):
    '''An Article contains many comments'''

    def __init__(self, title='Article Title', author='Article Author',
                 text='Article Text'):
        self.title = title
        self.author = author
        self.text   = text
        self.comments = OOBTree()
        self.lastcomment = 0L

    def add_comment(self, comment):
        self.lastcomment = self.lastcomment + 1L
        self.comments['%08d' % self.lastcomment] = (comment, time.time())

    def __str__(self):
        result = []
        result.append("Article(title='%s', author='%s',\n" \
                      % (self.title, self.author))
        result.append(" text='%s',\n" % self.text)
        for comment_id in self.comments:
            thecomment, when_added = self.comments[comment_id]
            result.append(" %s,\n comment_added=%s\n" \
                          % (str(thecomment), time.ctime(when_added)))
        result.append(")")
        return ''.join(result)
    
    def __repr__(self):
        return "<Article title='%s'>" % self.title
