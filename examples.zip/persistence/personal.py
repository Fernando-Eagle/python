class Personal(object):
    '''A personal record for HR databases'''
    def __init__(self, pid, firstname, middlename, surname):
        self.pid = pid
        self.firstname = firstname
        self.middlename = middlename
        self.surname = surname

    def __str__(self):
        return 'Personal(%s, %s %s. %s)' % (self.pid, self.firstname,
                                            self.middlename, self.surname)

