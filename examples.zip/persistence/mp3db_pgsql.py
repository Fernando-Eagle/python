#!/usr/bin/env python
# mp3db_pgsql.py -- update mp3collection database from mp3 meta data

import psycopg2

from mp3scan import scan_mp3
from mp3tree import tree_mp3

def update_database(dsn, root, debug=False):
    "Update database dsn, starting from root path"
    
    # Open PostgreSQL database and start transaction block
    conn = psycopg2.connect(dsn)
    curs = conn.cursor()
    
    for path in tree_mp3(root):
        # Read and compute meta data of file path
        m = scan_mp3(path)
        if debug: print "READ(%s)" % path
        if m is None: continue
        
        # Save meta data into mp3meta
        try:
            curs.execute('''INSERT INTO mp3meta VALUES
                         (%(sha1)s, %(title)s, %(artist)s, %(album)s,
                          %(track)s, %(genre)s, %(comment)s, %(year)s)''', m)
        except psycopg2.DatabaseError, e:
            print "ERR1(%s, %s):" % (m['sha1'], path), e
        conn.commit()
        
        # Save path info of this file into mp3paths
        try:
            curs.execute("INSERT INTO mp3paths VALUES (%(sha1)s, %(path)s)", m)
        except psycopg2.DatabaseError, e:
            print "ERR2(%s, %s):" % (m['sha1'], path), e
        conn.commit()
            
    # That's all, folks! Now let's clean up
    curs.close()
    conn.close()

if __name__ == '__main__':
    from getpass import getpass
    import sys
    
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "path_to_root"
        sys.exit(1)
    
    path_to_root = sys.argv[1]
    DSN = "dbname='pybookdb' user='pythonbook' host='127.0.0.1' " + \
          "password='%s'" % (getpass("Enter password for pythonbook: "),)
    
    update_database(DSN, path_to_root, debug=True)
