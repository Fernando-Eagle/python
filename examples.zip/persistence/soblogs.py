#!/usr/bin/env python
# soblogs.py -- A blogs system with SQLObject

from sqlobject import *

dsn = 'postgres://pythonbook:py.book@127.0.0.1/pybookdb'

class SoBlogs(object):
    def __init__(self, createTables=False, debug=False):
        self.dsn = dsn
        self.conn = connectionForURI(self.dsn)
        self.conn.debug = debug
        sqlhub.processConnection = self.conn
        if createTables:
            Blog.createTable()
            Article.createTable()
            Comment.createTable()

class Blog(SQLObject):
    name = StringCol()
    author = StringCol()
    descr = StringCol()
    added = DateTimeCol(default=DateTimeCol.now)
    articles = MultipleJoin('Article')

class Article(SQLObject):
    title = StringCol()
    author = StringCol()
    text = StringCol()
    added = DateTimeCol(default=DateTimeCol.now)
    blog = ForeignKey('Blog')
    comments = MultipleJoin('Comment')

class Comment(SQLObject):
    subject = StringCol()
    author = StringCol()
    text = StringCol()
    added = DateTimeCol(default=DateTimeCol.now)
    article = ForeignKey('Article')
