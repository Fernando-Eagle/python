class MyType(object):
    def hello(self):
        return 'hello!'
