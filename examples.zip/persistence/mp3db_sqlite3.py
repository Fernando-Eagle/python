#!/usr/bin/env python
# mp3db_sqlite3.py -- update mp3collection database from mp3 meta data

import sqlite3

from mp3scan import scan_mp3
from mp3tree import tree_mp3

def update_database(path_to_db, root, debug=False):
    "Update database, starting from root path"
    
    # Open SQLite3 database and start transaction block
    conn = sqlite3.connect(path_to_db, isolation_level='DEFERRED')
    curs = conn.cursor()
    
    for path in tree_mp3(root):
        # Read and compute meta data of file path
        m = scan_mp3(path)
        if debug: print "READ(%s)" % path
        if m is None: continue
        
        # Save meta data into mp3meta
        try:
            curs.execute('''INSERT INTO mp3meta VALUES
                         (?, ?, ?, ?, ?, ?, ?, ?)''',
                         (m['sha1'], m['title'], m['artist'], m['album'],
                          m['track'], m['genre'], m['comment'], m['year']))
        except sqlite3.IntegrityError, e:
            print "ERR1(%s, %s):" % (m['sha1'], path), e
        
        # Save path info of this file into mp3paths
        try:
            curs.execute('''INSERT INTO mp3paths VALUES (?, ?)''',
                         (m['sha1'], path))
        except sqlite3.IntegrityError, e:
            print "ERR2(%s, %s):" % (m['sha1'], path), e
    
    # Commit transaction now
    conn.commit()
    
    # That's all, folks! Now let's clean up
    curs.close()
    conn.close()

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 3:
        print >>sys.stderr, "Usage:", sys.argv[0], "path_to_db path_to_root"
        sys.exit(1)
    path_to_db, path_to_root = sys.argv[1], sys.argv[2]
    
    update_database(path_to_db, path_to_root, debug=True)
