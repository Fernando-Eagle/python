#!/usr/bin/env python
# mp3initdb_pgsql.py -- create mp3collection schemas in PostgreSQL

import psycopg2

MP3META_SCHEMA = '''
CREATE TABLE mp3meta (
id CHAR(40) PRIMARY KEY,
title VARCHAR(30),
artist VARCHAR(30),
album VARCHAR(30),
track VARCHAR(3),
genre VARCHAR(3),
comment VARCHAR(30),
year VARCHAR(4)
);
'''

MP3PATHS_SCHEMA = '''
CREATE TABLE mp3paths (
id CHAR(40) NOT NULL REFERENCES mp3meta(id),
path VARCHAR(255) NOT NULL
);
'''

MP3PATHS_INDEX_SCHEMA = '''
CREATE UNIQUE INDEX unique_index ON mp3paths ( id, path );
'''

def create_schema(dsn):
    "Create the tables within the pybookdb database"
    conn = psycopg2.connect(dsn)
    curs = conn.cursor()
    curs.execute(MP3META_SCHEMA)
    curs.execute(MP3PATHS_SCHEMA)
    curs.execute(MP3PATHS_INDEX_SCHEMA)
    conn.commit()
    curs.close()
    conn.close()

if __name__ == '__main__':
    from getpass import getpass
    DSN = "dbname='pybookdb' user='pythonbook' host='127.0.0.1' " + \
          "password='%s'" % (getpass("Enter password for pythonbook: "),)
    print "Schema(%s)" % (DSN,)
    create_schema(DSN)
