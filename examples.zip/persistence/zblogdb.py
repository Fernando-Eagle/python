#!/usr/bin/env python
# zblogdb.py -- A ZODB-persistent Blog system.

from ZODB import FileStorage, DB
from BTrees.OOBTree import OOBTree
import transaction
import logging

from zblog import Blog
from zarticle import Article
from zcomment import Comment

class BlogDB(object):
    '''A persistent Blog ZODB'''
    
    def __init__(self, zodbname='blogs', path_to_fs='/tmp/blogdb.fs'):
        self.zodbname   = zodbname
        self.path_to_fs = path_to_fs
        self.connect()
    
    def connect(self):
        self.logger     = logging.getLogger('ZODB.FileStorage')
        logger = self.logger
        self.storage    = FileStorage.FileStorage(self.path_to_fs)
        self.db         = DB(self.storage)
        self.conn       = self.db.open()
        self.dbroot     = self.conn.root()
        if self.zodbname not in self.dbroot:
            self.dbroot[self.zodbname] = OOBTree()
        self.blogsdb    = self.dbroot[self.zodbname]
    
    def close(self):
        self.conn.close();    self.conn    = None
        self.db.close();      self.db      = None
        self.storage.close(); self.storage = None
        self.dbroot  = None;  self.blogsdb = None
    
    def add_blog(self, newblog, commit=True):
        "Add a new Blog object to the ZODB"
        self.blogsdb[newblog.name] = newblog
        if commit:
            self.commit_changes()
    
    def get_blog_names(self):
        "Return a list of blog names"
        return list(self.blogsdb.keys())
    
    def get_blog_by_name(self, blogname):
        "Given a blog name, return Blog object or None."
        try:
            return self.blogsdb[blogname]
        except KeyError:
            return None
    
    def commit_changes(self):
        transaction.commit()
    
    def rollback_changes(self):
        transaction.abort()

if __name__ == '__main__':
    theblogdb = BlogDB()
