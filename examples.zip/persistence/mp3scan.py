#!/usr/bin/env python
# mp3scan.py -- scan an mp3 and return a dictionary

import parseid3
import fingerprint

def scan_mp3(path_to_mp3):
    "Scan an MP3 for vital data"
    mp3data = {}
    mp3data['path'] = path_to_mp3

    try:
        mp3data['sha1'] = fingerprint.compute_sha1(open(path_to_mp3, 'rb'))
    except IOError, e:
        print "EIO0: %s\n%s" % (path_to_mp3, e)       # Permission problem?
        return None

    id3 = parseid3.fetch_ID3tag(path_to_mp3)
    if id3 is None:
        print "EID3: %s" % path_to_mp3
        id3 = {}
        id3['title'] = id3['artist'] = id3['album'] = id3['comment'] = 'ERROR'
        id3['track'] = id3['genre']  = id3['year']  = None
    mp3data.update(id3)
    
    for key in mp3data.keys():
        if mp3data[key] is None:
            mp3data[key] = ''
    
    return mp3data

if __name__ == '__main__':
    import sys, pprint
    if len(sys.argv) != 2:
        print >>sys.stderr, "Usage:", sys.argv[0], "path/to/file.mp3"
        sys.exit(1)
    thepath = sys.argv[1]
    pprint.pprint(scan_mp3(thepath))
    
