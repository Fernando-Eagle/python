#!/usr/bin/env python
# demoshell.py -- import this into a python shell.

import math

radius = 10.0
circumference = 2 * math.pi * radius

def circ(rad):
    "compute the circumference of a circle of radius rad."
    return 2 * math.pi * rad
