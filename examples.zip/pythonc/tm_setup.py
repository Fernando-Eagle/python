#!/usr/bin/env python

from distutils.core import setup, Extension

tm_module = Extension('_tm',
                           sources = ['tm_wrap.c', ],
                          )

setup(name        = 'tm',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping struct tm and time(3) functions''',
      ext_modules = [tm_module],
      py_modules  = ["tm"],
     )
