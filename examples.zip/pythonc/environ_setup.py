#!/usr/bin/env python

from distutils.core import setup, Extension

environ_module = Extension('_environ',
                           sources = ['environ_wrap.c', ],
                          )

setup(name        = 'environ',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping getenv(3) and setenv(3)''',
      ext_modules = [environ_module],
      py_modules  = ["environ"],
     )
