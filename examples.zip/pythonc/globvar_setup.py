#!/usr/bin/env python

from distutils.core import setup, Extension

globvar_module = Extension('_globvar',
                           sources = ['globvar_wrap.c',
                                      'globvar.c'],
                          )

setup(name        = 'globvar',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping a global variable''',
      ext_modules = [globvar_module],
      py_modules  = ["globvar"],
     )
