#!/usr/bin/env python
# filecopy.py -- copy binary files with <stdio.h> functions.
#
# Source: SWIG Documentation.

from fileio import *

BLOCKSIZE = 8192

def filecopy(source, target):
    '''Copy file SOURCE to TARGET using fread/fwrite.
    
    The source file MUST contain a multiple of BLOCKSIZE bytes.
    If not, the last block will NOT be copied over!'''
    
    f1     = fopen(source, "r")
    f2     = fopen(target, "w")
    buf    = malloc(BLOCKSIZE)
    
    nrecs = fread(buf, BLOCKSIZE, 1, f1)
    while nrecs > 0:
        fwrite(buf, BLOCKSIZE, 1, f2)
        nrecs  = fread(buf, BLOCKSIZE, 1, f1)
    
    free(buf)
    fclose(f2)
    fclose(f1)
