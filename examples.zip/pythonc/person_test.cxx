// person_test.cxx -- testing the Person class

#include <iostream>
#include "person.h"

int main(int argc, char *argv[])
{
  Person p("John Doe");
  std::cout << "Name of p: " << p.get_name() << std::endl;
  p.set_name("Jane Doe");
  std::cout << "Name of p: " << p.get_name() << std::endl;

  Person p2(p);
  std::cout << "Name of p2: " << p2.get_name() << std::endl;

  return 0;
}
