#!/usr/bin/env python

from distutils.core import setup, Extension

uid_module = Extension('_uid',
                       sources = ['uid_wrap.c', ],
                      )

setup(name        = 'uid',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping UID/GID related functions''',
      ext_modules = [uid_module],
      py_modules  = ["uid"],
     )
