/* globvar.h -- global variables */

#ifndef _GLOBVAR_H_
#define _GLOBVAR_H_

extern int get_value(void);
extern void set_value(int value);

extern int global_var;

#endif /* _GLOBVAR_H_ */
