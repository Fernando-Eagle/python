#!/usr/bin/env python

from distutils.core import setup, Extension

hostname_module = Extension('_hostname',
                            sources = ['hostname_wrap.c', ],
                           )

setup(name        = 'hostname',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping gethostname(3)''',
      ext_modules = [hostname_module],
      py_modules  = ["hostname"],
     )
