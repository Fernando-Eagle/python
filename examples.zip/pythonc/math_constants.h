/* math_constants.h -- some math.h constants */

#ifndef _MATH_CONSTANTS_H_
#define _MATH_CONSTANTS_H_

#define	MM_E		2.7182818284590452354	/* e */
#define	MM_LOG2E	1.4426950408889634074	/* log 2e */
#define	MM_LOG10E	0.43429448190325182765	/* log 10e */
#define	MM_LN2		0.69314718055994530942	/* log e2 */
#define	MM_LN10		2.30258509299404568402	/* log e10 */

#define	MMAXFLOAT	((float)3.40282346638528860e+38)

enum Integers { ZERO, ONE, TWO, THREE, FOUR, FIVE };

const double MM_PI = 3.14159265358979323846;    /* pi */
const double MM_PI_2 = 1.57079632679489661923;  /* pi/2 */
const double MM_PI_4 = 0.78539816339744830962;  /* pi/4 */

#endif /* _MATH_CONSTANTS_H_ */
