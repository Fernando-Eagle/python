/* deepthought.c -- a complex function */

#include "deepthought.h"

int answer(void) {
  return THE_ANSWER;
}
