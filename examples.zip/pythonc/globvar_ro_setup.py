#!/usr/bin/env python

from distutils.core import setup, Extension

globvar_ro_module = Extension('_globvar_ro',
                              sources = ['globvar_ro_wrap.c',
                                         'globvar.c'],
                          )

setup(name        = 'globvar_ro',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping a global variable''',
      ext_modules = [globvar_ro_module],
      py_modules  = ["globvar_ro"],
     )
