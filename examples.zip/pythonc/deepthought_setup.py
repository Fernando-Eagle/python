#!/usr/bin/env python

from distutils.core import setup, Extension

deepthought_module = Extension('_deepthought',
                               sources = ['deepthought.c',
                                          'deepthought_wrap.c', ],
                               )

setup(name        = 'deepthought',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''A complex function''',
      ext_modules = [deepthought_module],
      py_modules  = ["deepthought"],
     )
