#!/usr/bin/env python

from distutils.core import setup, Extension

fileio_module = Extension('_fileio',
                           sources = ['fileio_wrap.c', ],
                          )

setup(name        = 'fileio',
      version     = '0.1',
      author      = 'SWIG Documentation',
      description = '''Wrapping the FILE data type''',
      ext_modules = [fileio_module],
      py_modules  = ["fileio"],
     )
