/* deepthought.h -- a complex function */

#ifndef _DEEPTHOUGHT_H_
#define _DEEPTHOUGHT_H_

#define THE_ANSWER 42

extern int answer(void);

#endif /* _DEEPTHOUGHT_H_ */
