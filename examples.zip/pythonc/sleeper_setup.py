#!/usr/bin/env python

from distutils.core import setup, Extension

sleeper_module = Extension('_sleeper',
                           sources = ['sleeper_wrap.c', ],
                          )

setup(name        = 'sleeper',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping sleep(3)''',
      ext_modules = [sleeper_module],
      py_modules  = ["sleeper"],
     )
