#!/usr/bin/env python

from distutils.core import setup, Extension

math_constants_module = Extension('_math_constants',
                                  sources = ['math_constants_wrap.c',],
                                 )

setup(name        = 'math_constants',
      version     = '0.1',
      author      = 'Farid Hajji',
      description = '''Wrapping constants in math_constants.h''',
      ext_modules = [math_constants_module],
      py_modules  = ["math_constants"],
     )
