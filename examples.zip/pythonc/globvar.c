/* globvar.c -- global variables */

#include "globvar.h"

int
get_value(void) {
  return global_var;
}

void
set_value(int value) {
  global_var = value;
}

/* A global variable shared by set_value and get_value */
int global_var = 0;
