#!/usr/bin/env python
# decimal_localcontext.py -- compute with specific precision

from __future__ import with_statement

import decimal

def sumprec(prec=6, arglist=[]):
    "Compute the sum of list arglist with precision prec."
    with decimal.localcontext() as lctx:
        # Here, computations should occur with precision prec
        lctx.prec = prec
        result = decimal.Decimal("0")
        for num in arglist:
            result = result + decimal.Decimal(num)
    # Resume computation with default or previous precision
    return result

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print "Usage:", sys.argv[0], "precision [num1 [num2 ...]]"
        sys.exit(1)
    print sumprec(int(sys.argv[1]), sys.argv[2:])
