#!/usr/bin/env python
# get_sample_naive.py -- Get a random sample from a population. Naive version.

import random

def get_sample_naive(population, size):
    "Return a list of size random elements from the list population."
    population_size = len(population)
    result = []
    i = 0
    while (i < size):
        idx = random.randrange(0, population_size)
        result.append(population[idx])
        i = i + 1
    return result

if __name__ == '__main__':
    print get_sample_naive(['apples', 'oranges', 'lemons', 'bananas'], 3)
