#!/usr/bin/env python
# tkhello.py -- Hello, World as a Tkinter application

import sys
from Tkinter import *

def build_gui():
    "Build the GUI. Return root, entry, and personalized greeting label"

    rootWindow = Tk()
    rootWindow.wm_geometry("500x200")
    
    label1 = Label(rootWindow)
    label1['text'] = "Hello, Tkinter World!"
    label1.pack()
    
    label2 = Label(rootWindow)
    label2['text'] = "What's your name?"
    label2.pack()

    nameEntry = Entry(rootWindow)
    nameEntry.bind('<Key-Return>', entry_callback)
    nameEntry.pack(fill=X)

    okButton = Button(rootWindow)
    okButton['text'] = 'OK'
    okButton['command'] = entry_callback
    okButton.pack(fill=X)
    
    exitButton = Button(rootWindow)
    exitButton['text'] = 'Exit'
    exitButton['command'] = exit_callback
    exitButton.pack(fill=X)

    outLabel = Label(rootWindow)
    outLabel['text'] = ''
    outLabel.pack()
    
    return rootWindow, nameEntry, outLabel

def entry_callback(event=None):
    "Called when the Return key is hit in the entry field or OK is clicked"
    name = theEntry.get()
    theLabel['text'] = "Nice to meet you, %s" % name

def exit_callback():
    "Called when the Exit button is hit"
    sys.exit(0)

def main():
    global theRoot, theEntry, theLabel
    theRoot, theEntry, theLabel = build_gui()
    theRoot.mainloop()

if __name__ == '__main__':
    main()
