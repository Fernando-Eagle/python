#!/usr/bin/env python
# hello.py -- the traditional hello world program.

print "Hello, World!"

name = raw_input("What's your name? ")
print "Nice to meet you,", name
