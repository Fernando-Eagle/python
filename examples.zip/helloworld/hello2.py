#!/usr/bin/env python
# hello2.py -- the traditional hello world program, cli version.

'''
This program greets the user and asks him for a name,
but only if the name has not been specified on the
command line interface as its first argument. Then
it welcomes the user with a nice personalized message.

Call this program either as:
  hello2.py "John Doe"
or as
  hello2.py
'''

import sys

def say_hello():
    "Say hello to the world"
    print "Hello, World!"

def ask_user_from_cli():
    "Fetch user name from the command line interface"
    if len(sys.argv) > 1:
        return sys.argv[1]
    else:
        return None

def ask_user_interactively():
    "Ask user for his name"
    return raw_input("What's your name? ")

def greet_user(name):
    "Send user a personalized greeting"
    print "Nice to meet you,", name

def main():
    "This is the main program"
    say_hello()
    name = ask_user_from_cli()
    if name is None:
        name = ask_user_interactively()
    greet_user(name)

if __name__ == '__main__':
    main()
