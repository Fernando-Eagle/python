#!/usr/bin/env python
# pyversion.py -- print current version of python

import sys

print sys.version, sys.prefix
