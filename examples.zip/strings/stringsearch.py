#!/usr/bin/env python
# stringsearch.py -- searching in strings with string methods

s   = raw_input('Enter source string: ')
sub = raw_input('Enter substring: ')

# The in operator returns True or False:
if sub in s:
    print "'%s' is a substring of '%s'" % (sub, s)
else:
    print "'%s' is NOT a substring of '%s'" % (sub, s)

# index, rindex return index (0-based), or raise ValueError:
try:
    idx = s.index(sub)
    ridx = s.rindex(sub)
    print "'%s'.index('%s') == %d" % (s, sub, idx)
    print "'%s'.rindex('%s') == %d" % (s, sub, ridx)
except ValueError:
    print "'%s' doesn't occur in '%s'" % (sub, s)

# find, rfind return index (0-based), or -1 if not found
pos = s.find(sub)
rpos = s.rfind(sub)
print "'%s'.find('%s') == %d" % (s, sub, pos)
print "'%s'.rfind('%s') == %d" % (s, sub, rpos)

# startswith, endswith return True or False
print "'%s'.startswith('%s') == " % (s, sub), s.startswith(sub)
print "'%s'.endswith('%s') == " % (s, sub), s.endswith(sub)

# count returns number of non-overlapping occurences:
print "'%s' occurs %d times in '%s'" % (sub, s.count(sub), s)
