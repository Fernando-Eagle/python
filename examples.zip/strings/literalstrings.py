#!/usr/bin/env python
# literalstrings.py -- writing literal strings.

# A singly-quoted string.
s1 = '<a href="http://www.example.com/">link</a>'

# A doubly-quoted string
s2 = "Joe's Appartment"

# A triply-quoted string with double quotes.
s3 = """foo(string) -> string

Transmogrify string, doing this and that.
Return the transmogrified string."""

# A triply-quoted string with single quotes.
s4 = '''<html>
  <head>
     <title>A title</title>
  </head>
  <body>
    <h1>A test page</h1>
    <div>
      <a href="http://www.example.com/">Back home</a>.
    </div>
  </body>
</html>'''
